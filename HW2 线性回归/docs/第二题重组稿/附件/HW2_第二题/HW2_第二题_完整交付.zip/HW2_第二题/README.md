# HW2 第二题交付

首先阅读 [实验报告](docs/第二题_实验报告.md)。已批准设计保存在 [实验方案](docs/第二题_实验方案.md)。

- `docs`：可编辑 Markdown 正文，包含实际公式、结果、配图和完整程序。
- `figures`：12 张正文图、3 张补充图，均有 PNG 与 SVG。
- `question2`：独立的问题二程序。
- `configs`：本次完整配置。
- `data`：原始第二组训练与测试 CSV 的副本。
- `results/complete`：逐折搜索、预测、指标、模型、公式、验证记录。

最终测试预测见 [test_predictions.csv](results/complete/test_predictions.csv)，按原测试行顺序保存房源编号、实际租金、预测租金及残差。

本次润色合并了 PCA 方差与验证误差分析（图4），为 t-SNE／UMAP 添加真实电梯属性及样本数标注（图6），新增 Lasso 的 64→30 项筛选图（图9）。所有图片的题注仅保留图名，含义与结论写在独立正文段落。模型、验证记录与测试预测沿用原有实验结果。

另见 [PaCMAP 试验记录](docs/第二题_PaCMAP试验.md)：复用同一批训练房源，与已存 UMAP 比较，包含六组 PaCMAP、两张双子图及结构保持和稳定性指标。新试验使用独立配置与结果目录，运行方式为 `python -m experiments.pacmap_trial --stage all`；附加依赖列在 `requirements-pacmap.txt` 中。

## 环境与运行

使用 Python 3.10 的 medsafety 环境，在本目录执行：

```powershell
conda activate medsafety
python -m pip install -r requirements-q2.txt
python -m question2.run --stage all
```

本机已用 medsafety 执行；UMAP 兼容依赖额外保存在 `.deps` 并由模块入口加载。可移植压缩包不含这组 Windows 二进制依赖，按上面的固定版本安装即可。

支持 `compare`、`finalize`、`embedding`、`plot`、`report`、`verify` 分阶段运行。重绘不重新训练；最终评价已存在时使用保存结果。更改配置时将 output 改为新的目录。完整重新运行时也可指定一个新的输出目录；报告与图形由该次结果重新生成。

## 审查要点

最低外层 RMSE 属于样条＋Lasso；按预先规定的一个标准误和简洁性规则，最终选择二次特征＋Lasso。两者在报告中分别说明。

最终测试 RMSE 127.21 元/月，MAE 102.20 元/月，R² 0.9830。最终公式还原为原始单位，包含 30 个非零项。房源编号不进入模型，测试集不参与模型选择。

Markdown 使用相对图片路径，移动报告时保留其与 figures 的目录关系。已核验 PNG、数学定界符及文件引用，未实际打开 Markpad 或 Obsidian。桌面原项目未改写，本目录为独立交付。
