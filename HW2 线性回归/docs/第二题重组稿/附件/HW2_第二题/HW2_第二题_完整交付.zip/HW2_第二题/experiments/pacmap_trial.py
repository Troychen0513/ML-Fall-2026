"""PaCMAP 可视化试验：复用训练子样本与 UMAP，不重新拟合租金模型。"""

import argparse
import hashlib
import json
import sys
import time
from importlib.metadata import version
from itertools import combinations
from question2 import ROOT
import numpy as np
import pandas as pd
import yaml
from scipy.stats import spearmanr
from sklearn.manifold import trustworthiness
from sklearn.neighbors import NearestNeighbors
from threadpoolctl import threadpool_limits
from question2.features import NAMES, read_data, save_json
from question2.plot import style
import matplotlib.pyplot as plt
from matplotlib.cm import ScalarMappable
from matplotlib.colors import Normalize


def neighbors(points, k):
    return NearestNeighbors(n_neighbors=k).fit(points).kneighbors(return_distance=False)


def overlap(first, second):
    values = [len(set(a) & set(b)) / len(a) for a, b in zip(first, second)]
    return float(np.mean(values))


def sample_pairs(size, count, seed):
    rng = np.random.default_rng(seed)
    pairs = set()
    while len(pairs) < count:
        a, b = rng.choice(size, 2, replace=False)
        pairs.add(tuple(sorted((int(a), int(b)))))
    return np.array(sorted(pairs))


def run_embeddings(config, output, data):
    from pacmap import PaCMAP

    source = ROOT / config["source"]
    z = data["z"]
    settings = config["evaluation"]
    k = settings["neighbors"]
    pairs = sample_pairs(len(z), settings["pair_count"], settings["pair_seed"])
    np.savez_compressed(output / "evaluation_pairs.npz", pairs=pairs, sample=data["sample"])
    original_neighbors = neighbors(z, k)
    original_distances = np.linalg.norm(z[pairs[:, 0]] - z[pairs[:, 1]], axis=1)
    results, neighbor_records = [], {}
    specs = [("UMAP", 30, seed) for seed in config["seeds"]]
    specs += [("PaCMAP", n, seed) for n in config["neighbors"] for seed in config["seeds"]]
    with threadpool_limits(limits=1):
        for method, n, seed in specs:
            if method == "UMAP":
                path = source / "embeddings" / f"umap_{seed}_30_0.1.npz"
                coords = np.load(path)["coords"]
                seconds = None
            else:
                path = output / f"pacmap_{seed}_{n}.npz"
                if not path.exists():
                    start = time.perf_counter()
                    model = PaCMAP(n_neighbors=n, random_state=seed, **config["pacmap"])
                    coords = model.fit_transform(z.copy(), init="pca", save_pairs=True)
                    seconds = time.perf_counter() - start
                    np.savez_compressed(path, coords=coords, sample=data["sample"], seconds=seconds,
                                        near=model.pair_neighbors, mid=model.pair_MN, far=model.pair_FP)
                record = np.load(path)
                coords, seconds = record["coords"], float(record["seconds"])
            assert coords.shape == (len(z), 2) and np.isfinite(coords).all()
            local = neighbors(coords, k)
            neighbor_records[(method, n, seed)] = local
            distances = np.linalg.norm(coords[pairs[:, 0]] - coords[pairs[:, 1]], axis=1)
            result = dict(method=method, neighbors=n, seed=seed,
                          trustworthiness=float(trustworthiness(z, coords, n_neighbors=k)),
                          neighbor_overlap=overlap(original_neighbors, local),
                          distance_rank=float(spearmanr(original_distances, distances).statistic),
                          fit_seconds=seconds)
            results.append(result)
            pd.DataFrame(results).to_csv(output / "metrics.csv", index=False, encoding="utf-8-sig")
            print("RESULT", json.dumps(result, ensure_ascii=False), flush=True)
    stability = []
    for method, n in [("UMAP", 30)] + [("PaCMAP", n) for n in config["neighbors"]]:
        for first, second in combinations(config["seeds"], 2):
            score = overlap(neighbor_records[(method, n, first)], neighbor_records[(method, n, second)])
            stability.append(dict(method=method, neighbors=n, first=first, second=second, overlap=score))
    pd.DataFrame(stability).to_csv(output / "stability.csv", index=False, encoding="utf-8-sig")


def draw_comparison(data, paths, titles, elevator, rotations, filename, dpi):
    style()
    norm = Normalize(float(data["y"].min()), float(data["y"].max()))
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 4.2), layout="constrained")
    for ax, path, title, degrees in zip(axes, paths, titles, rotations):
        coords = np.load(path)["coords"]
        angle = np.deg2rad(degrees)
        rotation = [[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]]
        coords = coords @ np.array(rotation)
        ax.scatter(coords[:, 0], coords[:, 1], c=data["y"], cmap="viridis", norm=norm,
                   s=6, alpha=.82, linewidths=0, rasterized=True)
        center = np.median(coords, axis=0)
        for value, label in [(0, "无电梯"), (1, "有电梯")]:
            group = coords[elevator == value]
            anchor = np.median(group, axis=0)
            position = (.1 if anchor[0] < center[0] else .89,
                        .94 if anchor[1] > center[1] else .08)
            ax.annotate(f"{label}\n{len(group):,} 套", anchor, xytext=position,
                        textcoords="axes fraction", ha="center", va="center", fontsize=8.5,
                        color="#344256", bbox=dict(boxstyle="round,pad=.4", fc="white", ec="#DCE3EB"),
                        arrowprops=dict(arrowstyle="-", color="#8F9DAD", lw=.8, shrinkA=5))
        ax.set(xticks=[], yticks=[])
        ax.set_title(title, loc="left", fontweight="bold", pad=16)
        ax.set_aspect("equal", adjustable="box")
        ax.set_anchor("N")
        ax.margins(x=.19, y=.24)
        for spine in ax.spines.values():
            spine.set_visible(False)
    colorbar = fig.colorbar(ScalarMappable(norm=norm, cmap="viridis"), ax=axes,
                            orientation="horizontal", fraction=.038, shrink=.65, pad=.04, aspect=38)
    colorbar.set_label("月租金（元/月）")
    colorbar.outline.set_visible(False)
    for extension in ["png", "svg"]:
        fig.savefig(filename.with_suffix("."+extension), dpi=dpi, bbox_inches="tight")
    plt.close(fig)


def make_figures(config, output, data):
    _, x, y = read_data(ROOT / "data/B_train.csv")
    assert np.array_equal(data["y"], y[data["sample"]])
    elevator = x[data["sample"], NAMES.index("has_elevator")]
    folder = ROOT / "figures/pacmap_trial"
    folder.mkdir(exist_ok=True)
    primary = config["primary_neighbors"]
    paths = [ROOT / config["source"] / "embeddings/umap_42_30_0.1.npz",
             output / f"pacmap_42_{primary}.npz"]
    draw_comparison(data, paths, ["A  UMAP · 30 近邻", f"B  PaCMAP · {primary} 近邻"],
                    elevator, [35, 0], folder / "pacmap_vs_umap", config["dpi"])
    paths = [output / f"pacmap_42_{n}.npz" for n in [10, 30]]
    draw_comparison(data, paths, ["A  PaCMAP · 10 近邻", "B  PaCMAP · 30 近邻"],
                    elevator, [0, 0], folder / "pacmap_neighbors", config["dpi"])


def make_report(config, output):
    metrics = pd.read_csv(output / "metrics.csv")
    stability = pd.read_csv(output / "stability.csv")
    primary = config["primary_neighbors"]
    means = metrics.groupby(["method", "neighbors"]).mean(numeric_only=True)
    baseline = means.loc[("UMAP", 30)]
    main = means.loc[("PaCMAP", primary)]
    default = means.loc[("PaCMAP", 10)]
    lines = ["# 问题二：PaCMAP 可视化试验", "",
             "本试验比较房源结构的二维呈现，不重新训练租金预测模型，也不根据投影修改已选特征。",
             "", "## 试验设置", "",
             "复用原实验固定抽取的 3,000 条训练房源及十维标准化输入。编号和租金均不进入降维拟合；"
             "租金仅在拟合完成后着色。原 UMAP 坐标直接读取已保存结果。",
             "", f"主图预先固定 PaCMAP 为 {primary} 个近邻、种子 42；另比较默认的 10 个近邻，"
             "两组均使用种子 42、2026、3407。MN_ratio=0.5、FP_ratio=2.0，二维 PCA 初始化，"
             "学习率 1.0，三阶段迭代次数为 100、100、250，欧氏距离与 FAISS 近邻后端。"
             "原始十维输入全部保留；库内部统一缩放与中心化不改变高维距离的排序。",
             "", "## 结构保持与稳定性", "",
             "| 方法 | 近邻数 | 邻域可信度 | 原始近邻重合率 | 距离秩相关 | 随机种子稳定性 |",
             "| --- | --- | --- | --- | --- | --- |"]
    for (method, n), rows in metrics.groupby(["method", "neighbors"], sort=False):
        values = [method, str(n)]
        for key in ["trustworthiness", "neighbor_overlap", "distance_rank"]:
            values.append(f"{rows[key].mean():.4f} ± {rows[key].std(ddof=1):.4f}")
        stable = stability[(stability.method == method) & (stability.neighbors == n)].overlap
        values.append(f"{stable.mean():.4f} ± {stable.std(ddof=1):.4f}")
        lines.append("| " + " | ".join(values) + " |")
    lines += ["", "前两项均使用 15 个近邻。邻域可信度主要检查二维近邻中是否混入原本较远的房源；"
              "近邻重合率直接统计原始 15 个近邻保留了多少。距离秩相关使用固定抽取的 20,000 对不同房源，"
              "比较高维与二维欧氏距离的 Spearman 相关，用于补充整体远近关系。",
              "", "前三项报告三个种子的均值与标准差；稳定性报告三个种子两两之间二维近邻重合率的均值与标准差。"
              "这些指标各有侧重，不合成为一个分数，也不作为预测准确率。标准差不是置信区间。",
              "", "## 主图：PaCMAP 与 UMAP", "",
              "![图P1 PaCMAP 与 UMAP 的房源结构对照](../figures/pacmap_trial/pacmap_vs_umap.png)", "",
              "**图P1 PaCMAP 与 UMAP 的房源结构对照**", "",
              "两图共用样本、租金色标、点大小和透明度；坐标等比例显示。UMAP 沿用原报告的整体旋转 35°，"
              "PaCMAP 使用保存坐标，不拉伸点云。引线指向实际电梯组的坐标中位位置，"
              "标签中的 797 套和 2,203 套来自真实属性，不是算法识别的聚类数量。",
              "", "主图中，两种方法均呈现与电梯分组基本对应的两个主要区域，各区域内部仍有明显租金梯度。"
              "PaCMAP 改变了组内点位排列，但这张图尚未提供额外房源类别的独立证据；"
              "组间空隙的大小也不能直接解释为原始房源差异或预测效果。",
              "", "## 补充图：近邻设置", "",
              "![图P2 PaCMAP 对近邻数量的敏感性](../figures/pacmap_trial/pacmap_neighbors.png)", "",
              "**图P2 PaCMAP 对近邻数量的敏感性**", "",
              "在种子 42 下比较 10 与 30 个近邻；其余 PaCMAP 设置相同。"
              "方法之间近邻参数的作用不完全相同，因此相同数值不意味着等价的优化目标。"
              "样本群更分离不能单独证明结构保留更好，应与上表的局部、整体及稳定性指标共同判断。",
              "", f"两种近邻设置仍呈现相似的主体分组，但群内排列不同。三个种子的原始近邻重合率，"
              f"10 近邻为 {default.neighbor_overlap:.2%}，30 近邻为 {main.neighbor_overlap:.2%}。"
              "本次 10 近邻更有利于保留局部关系，因此不能认为增大近邻数必然改善可视化。",
              "", "## 本次结论", "",
              f"PaCMAP 的 30 近邻设置在抽样距离秩相关上为 {main.distance_rank:.4f}，"
              f"略高于 UMAP 的 {baseline.distance_rank:.4f}，但原始近邻重合率由 "
              f"{baseline.neighbor_overlap:.2%} 降至 {main.neighbor_overlap:.2%}，不同种子的二维邻域也更不稳定。"
              "整体指标的改善幅度较小，不能据此认定 PaCMAP 综合更好。",
              "", "默认 10 近邻改善了 PaCMAP 的局部表现，仍未超过当前 UMAP。建议现阶段保留 UMAP "
              "作为正文主要非线性投影，将 PaCMAP 作为补充方法对照。本结论限于相同输入、六组 PaCMAP "
              "运行及所用指标，不代表 UMAP 对所有数据或参数都更优。租金预测模型及其测试结果不受本试验影响。",
              "", "## 复现", "",
              "使用 medsafety 环境；本机附加依赖位于项目 .deps，解释器保持不变。", "",
              "```powershell", "conda activate medsafety", "python -m pip install -r requirements-pacmap.txt",
              "python -m experiments.pacmap_trial --stage all", "```", "",
              "run 计算六组 PaCMAP 并比较已存 UMAP；plot 只重绘；report 只更新本记录。"
              "配置、坐标、抽样点对、各组结构指标、种子稳定性及依赖版本保存在 results/pacmap_trial。",
              "", "已检查图像、图片路径与正文源码一致性；未实际打开 Markpad 或 Obsidian 核验界面渲染。",
              "", "文献：[PaCMAP 原始论文](https://jmlr.org/papers/v22/20-1061.html)。", "",
              "## 实际代码与配置", ""]
    for name in ["configs/pacmap_trial.yaml", "requirements-pacmap.txt", "experiments/pacmap_trial.py"]:
        language = "python" if name.endswith(".py") else "yaml" if name.endswith(".yaml") else "text"
        source = (ROOT / name).read_text(encoding="utf-8").rstrip()
        lines += [f"### {name}", "", f"```{language}", source, "```", ""]
    (ROOT / "docs/第二题_PaCMAP试验.md").write_text("\n".join(lines), encoding="utf-8")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--stage", choices=["all", "run", "plot", "report"], default="all")
    args = parser.parse_args()
    config_path = ROOT / "configs/pacmap_trial.yaml"
    config = yaml.safe_load(config_path.read_text(encoding="utf-8"))
    output = ROOT / config["output"]
    output.mkdir(parents=True, exist_ok=True)
    source_path = ROOT / config["source"] / "pca.npz"
    snapshot = dict(config=config, input_sha256=hashlib.sha256(source_path.read_bytes()).hexdigest())
    snapshot_path = output / "config_snapshot.json"
    if snapshot_path.exists():
        assert json.loads(snapshot_path.read_text(encoding="utf-8")) == snapshot, "请更换输出目录以运行新配置"
    save_json(snapshot_path, snapshot)
    data = np.load(source_path)
    if args.stage in {"all", "run"}:
        packages = ["pacmap", "faiss-cpu", "numpy", "scipy", "scikit-learn", "numba", "matplotlib"]
        save_json(output / "environment.json", dict(python=sys.executable, versions={p: version(p) for p in packages}))
        run_embeddings(config, output, data)
    if args.stage in {"all", "plot"}:
        make_figures(config, output, data)
    if args.stage in {"all", "report"}:
        make_report(config, output)


if __name__ == "__main__":
    main()
