"""训练子样本上的无监督投影及敏感性实验；租金仅用于后续着色。"""

import time
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA
from sklearn.manifold import TSNE, trustworthiness
from sklearn.neighbors import NearestNeighbors
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from umap import UMAP
from . import ROOT
from .features import read_data, save_json


def neighborhood(z, k=15):
    return NearestNeighbors(n_neighbors=k).fit(z).kneighbors(return_distance=False)


def run_embeddings(config, output):
    _, x, y = read_data(ROOT / config["data"]["train"])
    settings = config["visualization"]
    sample = np.sort(np.random.default_rng(42).choice(len(x), settings["sample_size"], replace=False))
    z = StandardScaler().fit_transform(x[sample])
    base = PCA(svd_solver="full").fit(z)
    np.savez_compressed(output / "pca.npz", sample=sample, y=y[sample], z=z,
                        scores=base.transform(z), components=base.components_, variance=base.explained_variance_ratio_)
    folder = output / "embeddings"
    folder.mkdir(exist_ok=True)
    original_neighbors = neighborhood(z)
    specs = []
    for seed in settings["seeds"]:
        for p in settings["perplexities"]:
            specs.append(dict(method="tsne", seed=seed, perplexity=p))
        for k in settings["neighbors"]:
            for distance in settings["min_dist"]:
                specs.append(dict(method="umap", seed=seed, neighbors=k, min_dist=distance))
    # PCA 初始化在十维输入下可能不受种子影响，另检验三次随机初始化。
    for seed in settings["seeds"]:
        specs.append(dict(method="tsne", seed=seed, perplexity=30, init="random"))
    # 固定正文参数优先运行，便于先检查图形。
    specs.sort(key=lambda s: (s["seed"] != 42, s.get("perplexity", 30) != 30,
                             s.get("neighbors", 30) != 30, s.get("min_dist", 0.1) != 0.1))
    results = []
    with threadpool_limits(limits=1):
        for spec in specs:
            name = "_".join(str(v) for v in spec.values())
            path = folder / f"{name}.npz"
            start = time.time()
            if path.exists():
                coords = np.load(path)["coords"]
            elif spec["method"] == "tsne":
                coords = TSNE(n_components=2, perplexity=spec["perplexity"], init=spec.get("init", "pca"),
                              learning_rate="auto", max_iter=2000, random_state=spec["seed"], n_jobs=1).fit_transform(z)
                np.savez_compressed(path, coords=coords)
            else:
                coords = UMAP(n_components=2, n_neighbors=spec["neighbors"], min_dist=spec["min_dist"],
                              random_state=spec["seed"], transform_seed=spec["seed"], n_jobs=1).fit_transform(z)
                np.savez_compressed(path, coords=coords)
            neighbors = neighborhood(coords)
            overlap = np.mean([len(set(a) & set(b)) / 15 for a, b in zip(original_neighbors, neighbors)])
            result = dict(spec, file=path.name, trustworthiness=float(trustworthiness(z, coords, n_neighbors=15)),
                          neighbor_overlap=float(overlap), seconds=time.time()-start)
            results.append(result)
            pd.DataFrame(results).to_csv(output / "embedding_metrics.csv", index=False, encoding="utf-8-sig")
            print("EMBED", name, f"trust={result['trustworthiness']:.4f} overlap={overlap:.4f}", flush=True)
    # 随机种子稳定性：同一设置在不同种子下的二维近邻重合比例。
    stability = []
    for method in ["tsne", "umap"]:
        subset = [r for r in results if r["method"] == method]
        for setting in subset:
            if setting["seed"] != 42:
                continue
            keys = ["perplexity", "init"] if method == "tsne" else ["neighbors", "min_dist"]
            baseline = neighborhood(np.load(folder / setting["file"])["coords"])
            for other in subset:
                if other["seed"] == 42 or not all(other.get(k, "pca") == setting.get(k, "pca") for k in keys):
                    continue
                neighbor = neighborhood(np.load(folder / other["file"])["coords"])
                overlap = np.mean([len(set(a) & set(b)) / 15 for a, b in zip(baseline, neighbor)])
                stability.append(dict(method=method, seed=other["seed"], overlap=float(overlap),
                                      **{k: setting.get(k, "pca") for k in keys}))
    save_json(output / "embedding_stability.json", stability)
