"""原始单位输入、无目标信息的特征工程，以及可导出的模型表达式。"""

import json
import warnings
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin, RegressorMixin
from sklearn.preprocessing import OneHotEncoder, PolynomialFeatures, SplineTransformer
from sklearn.linear_model import LinearRegression, Ridge, Lasso, ElasticNet
from sklearn.exceptions import ConvergenceWarning

NAMES = ["area_sqm", "building_age_years", "metro_km", "center_km", "bedrooms",
         "floor", "amenities_1km", "renovation_score", "has_elevator", "sunlight_hours"]
LABELS = ["面积", "房龄", "地铁距离", "市中心距离", "卧室数", "楼层", "配套数", "装修评分", "电梯", "日照"]
BLOCKS = ("space", "location", "access", "quality")
EXTRA = {"space": ["area_per_bedroom"], "location": ["log_metro", "log_center"],
         "access": ["floor_no_elevator"], "quality": ["area_renovation", "age_renovation"]}
SPLINE_COLS = [0, 1, 2, 3, 5, 6, 9]


def read_data(path, target=True):
    frame = pd.read_csv(path)
    frame["metro_km"] = frame["metro_m"] / 1000
    x = frame[NAMES].to_numpy(float)
    if not np.isfinite(x).all() or frame.listing_id.duplicated().any():
        raise ValueError("输入存在非有限值或重复房源编号。")
    if (x[:, 4] <= 0).any():
        raise ValueError("卧室数必须为正，才能计算每卧室面积。")
    y = frame.monthly_rent.to_numpy(float) if target else None
    if y is not None and not np.isfinite(y).all():
        raise ValueError("目标存在非有限值。")
    return frame.listing_id.to_numpy(dtype=str), x, y


class FeatureMap(TransformerMixin, BaseEstimator):
    def __init__(self, kind="raw", categories=(), blocks=BLOCKS, knots=4):
        self.kind = kind
        self.categories = categories
        self.blocks = blocks
        self.knots = knots

    def fit(self, x, y=None):
        self.names_ = list(NAMES)
        if self.kind == "encoded":
            self.keep_ = [j for j in range(10) if j not in self.categories]
            self.encoder_ = OneHotEncoder(categories=[np.arange(1, 6)] * len(self.categories),
                                         drop="first", sparse_output=False)
            self.encoder_.fit(x[:, self.categories])
            self.names_ = [NAMES[j] for j in self.keep_]
            for j in self.categories:
                self.names_ += [f"{NAMES[j]}={k}" for k in range(2, 6)]
        elif self.kind == "domain":
            for block in self.blocks:
                self.names_ += EXTRA[block]
        elif self.kind == "quadratic":
            self.poly_ = PolynomialFeatures(2, include_bias=False).fit(x)
            names = self.poly_.get_feature_names_out(NAMES)
            self.keep_ = np.flatnonzero(names != "has_elevator^2")
            self.names_ = names[self.keep_].tolist()
        elif self.kind == "spline":
            self.spline_ = SplineTransformer(n_knots=self.knots, degree=3, knots="quantile",
                                            include_bias=False, extrapolation="linear")
            self.spline_.fit(x[:, SPLINE_COLS])
            self.names_ = self.spline_.get_feature_names_out(np.array(NAMES)[SPLINE_COLS]).tolist()
            self.names_ += [NAMES[j] for j in [4, 7, 8]]
        return self

    def transform(self, x):
        if self.kind == "encoded":
            return np.column_stack([x[:, self.keep_], self.encoder_.transform(x[:, self.categories])])
        if self.kind == "quadratic":
            return self.poly_.transform(x)[:, self.keep_]
        if self.kind == "spline":
            return np.column_stack([self.spline_.transform(x[:, SPLINE_COLS]), x[:, [4, 7, 8]]])
        if self.kind == "domain":
            extras = {"space": [x[:, 0] / x[:, 4]],
                      "location": [np.log1p(x[:, 2]), np.log1p(x[:, 3])],
                      "access": [x[:, 5] * (1 - x[:, 8])],
                      "quality": [x[:, 0] * x[:, 7], x[:, 1] * x[:, 7]]}
            columns = [x]
            for block in self.blocks:
                columns.extend(extras[block])
            return np.column_stack(columns)
        return np.asarray(x, dtype=float)


class CheckedLinear(RegressorMixin, BaseEstimator):
    """统一参数入口；收敛警告必须重试，仍失败则排除该候选。"""
    def __init__(self, kind="ols", alpha=1.0, l1_ratio=0.5):
        self.kind = kind
        self.alpha = alpha
        self.l1_ratio = l1_ratio

    def fit(self, x, y):
        estimators = {"ols": LinearRegression(), "ridge": Ridge(alpha=self.alpha),
                      "lasso": Lasso(alpha=self.alpha, max_iter=50000, tol=1e-6),
                      "elastic": ElasticNet(alpha=self.alpha, l1_ratio=self.l1_ratio,
                                            max_iter=50000, tol=1e-6)}
        self.estimator_ = estimators[self.kind]
        self.retried_ = False
        with warnings.catch_warnings():
            warnings.simplefilter("error", ConvergenceWarning)
            try:
                self.estimator_.fit(x, y)
            except ConvergenceWarning:
                self.estimator_.set_params(max_iter=200000)
                self.retried_ = True
                self.estimator_.fit(x, y)
        self.coef_ = self.estimator_.coef_
        self.intercept_ = self.estimator_.intercept_
        return self

    def predict(self, x):
        return self.estimator_.predict(x)


def export_formula(pipeline):
    feature = pipeline.named_steps["features"]
    scale = pipeline.named_steps["scale"]
    model = pipeline.named_steps["model"]
    coef = np.asarray(model.coef_).reshape(-1)
    intercept = float(np.asarray(model.intercept_).reshape(-1)[0])
    if "pca" in pipeline.named_steps:
        pca = pipeline.named_steps["pca"]
        coef = pca.components_.T @ coef
        intercept -= float(pca.mean_ @ coef)
    if hasattr(model, "_x_mean"):
        intercept -= float(model._x_mean @ coef)
    raw_coef = coef / scale.scale_
    intercept -= float(scale.mean_ @ raw_coef)
    result = dict(intercept=intercept, coefficients=raw_coef.tolist(), names=feature.names_,
                  feature_spec=feature.get_params(), scale_mean=scale.mean_.tolist(),
                  scale_std=scale.scale_.tolist(), standardized_coefficients=coef.tolist())
    if feature.kind == "spline":
        result["spline_knots"] = [b.t.tolist() for b in feature.spline_.bsplines_]
        result["spline_degree"] = 3
    return result


def save_json(path, value):
    def convert(obj):
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, np.generic):
            return obj.item()
        raise TypeError(type(obj).__name__)
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2, default=convert,
                               allow_nan=False), encoding="utf-8")
