"""训练结果与绘图分离：每图最多两个数据子图。"""

import json
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.colors import Normalize
from matplotlib.cm import ScalarMappable
from matplotlib.patches import Patch
from . import ROOT
from .features import NAMES, LABELS, BLOCKS, read_data, save_json

COLORS = ["#4776B4", "#299A91", "#E4A04B", "#9975B6"]
FAMILY_LABEL = {"raw": "原始特征", "encoded": "类别编码", "domain": "含义组合",
                "quadratic": "二次特征", "spline": "加性样条", "pcr": "PCA 回归", "pls": "PLS 回归"}
METHOD_LABEL = {"ols": "OLS", "ridge": "Ridge", "lasso": "Lasso", "elastic": "Elastic Net", "pls": "PLS"}
BLOCK_LABEL = {"space": "空间", "location": "区位", "access": "通行", "quality": "品质"}


def style():
    plt.rcParams.update({"font.family": "Microsoft YaHei", "font.size": 10,
                         "axes.unicode_minus": False, "axes.spines.top": False,
                         "axes.spines.right": False, "axes.edgecolor": "#C7D0DB",
                         "axes.labelcolor": "#344256", "xtick.color": "#506078",
                         "ytick.color": "#506078", "grid.color": "#E7ECF2",
                         "axes.titleweight": "medium", "axes.titlesize": 11,
                         "legend.frameon": False, "legend.fontsize": 9,
                         "savefig.facecolor": "white", "svg.fonttype": "path"})


def axes_pair():
    return plt.subplots(1, 2, figsize=(7.2, 3.35), layout="constrained")


def light_grid(ax, axis="y"):
    ax.grid(axis=axis, alpha=0.8)
    ax.set_axisbelow(True)


def pca_analysis(data, comparison):
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 3.7), layout="constrained")
    k = np.arange(1, len(data["variance"]) + 1)
    cumulative = np.cumsum(data["variance"]) * 100
    ax[0].fill_between(k, 0, cumulative, color=COLORS[0], alpha=.08)
    ax[0].plot(k, cumulative, "o-", color=COLORS[0], lw=2, ms=4)
    for index, offset in [(1, (12, -28)), (8, (-50, -32))]:
        ax[0].scatter(k[index], cumulative[index], s=44, color=COLORS[2], zorder=4)
        ax[0].annotate(f"{k[index]} 个成分 · {cumulative[index]:.2f}%",
                       (k[index], cumulative[index]), xytext=offset,
                       textcoords="offset points", fontsize=9, color="#344256")
    ax[0].set(xlabel="保留主成分数", ylabel="累计解释方差（%）",
              title="A  保留了多少输入变化", xlim=(.7, 10.3), ylim=(0, 108),
              xticks=[1, 2, 4, 6, 8, 10], yticks=[0, 25, 50, 75, 100])
    for family, color in zip(["pcr", "pls"], COLORS):
        rows = comparison[comparison.candidate.str.startswith(f"dimension:{family}:")].copy()
        rows["k"] = rows.candidate.str.split(":").str[-1].astype(int)
        rows = rows.sort_values("k")
        ax[1].plot(rows.k, rows.rmse, "o-", color=color, label=FAMILY_LABEL[family], ms=4, lw=1.8)
        ax[1].fill_between(rows.k, rows.rmse-rows.rmse_std, rows.rmse+rows.rmse_std,
                           color=color, alpha=.12)
    reference = comparison.set_index("candidate").loc["raw:ols", "rmse"]
    ax[1].axhline(reference, color="#7C899A", ls="--", lw=1, zorder=1)
    ax[1].text(5.5, reference-36, f"原始 OLS · {reference:.2f}",
               ha="center", va="top", color="#65748A", fontsize=8.5)
    ax[1].set(xlabel="保留成分数", ylabel="验证 RMSE（元/月）",
              title="B  保留了多少预测信息", xlim=(.7, 10.3), ylim=(80, 850),
              xticks=[1, 2, 4, 6, 8, 10], yticks=[200, 400, 600, 800])
    ax[1].legend(loc="upper right")
    for a in ax:
        light_grid(a)
    return fig


def embedding_comparison(data, files, elevator, norm):
    fig, ax = plt.subplots(1, 2, figsize=(7.2, 4.2), layout="constrained")
    label_positions = [(.08, .94), (.91, .08)]
    for i, (a, path, title) in enumerate(zip(ax, files, ["A  t-SNE", "B  UMAP"])):
        coords = np.load(path)["coords"]
        if i == 1:
            # 仅旋转显示方向，保持点间距离；不改变保存的投影结果。
            angle = np.deg2rad(35)
            rotation = [[np.cos(angle), -np.sin(angle)], [np.sin(angle), np.cos(angle)]]
            coords = coords @ np.array(rotation)
        a.scatter(coords[:, 0], coords[:, 1], c=data["y"], cmap="viridis", norm=norm,
                  s=6, alpha=.82, linewidths=0, rasterized=True)
        for value, label in [(0, "无电梯"), (1, "有电梯")]:
            subset = coords[elevator == value]
            anchor = np.median(subset, axis=0)
            a.annotate(f"{label}\n{len(subset):,} 套", anchor,
                       xytext=label_positions[value], textcoords="axes fraction",
                       ha="center", va="center", fontsize=8.5, color="#344256",
                       bbox=dict(boxstyle="round,pad=.4", fc="white", ec="#DCE3EB", lw=.8),
                       arrowprops=dict(arrowstyle="-", color="#8F9DAD", lw=.9,
                                       shrinkA=5, shrinkB=4))
        a.set(xticks=[], yticks=[])
        a.set_title(title, loc="left", fontweight="bold", pad=16)
        a.set_aspect("equal", adjustable="box")
        a.set_anchor("N")
        a.margins(x=.17, y=.22)
        for spine in a.spines.values():
            spine.set_visible(False)
    colorbar = fig.colorbar(ScalarMappable(norm=norm, cmap="viridis"), ax=ax,
                            orientation="horizontal", fraction=.038, shrink=.65, pad=.04, aspect=38)
    colorbar.set_label("月租金（元/月）", labelpad=5)
    colorbar.outline.set_visible(False)
    return fig


def term_counts(formula):
    """按实际保存的项名分类；系数恰为零表示该项被移除。"""
    counts = {name: [0, 0] for name in ["一次项", "平方项", "交互项"]}
    for name, coefficient in zip(formula["names"], formula["coefficients"]):
        group = "交互项" if " " in name else "一次项"
        if "^2" in name:
            group = "平方项"
        counts[group][0] += 1
        counts[group][1] += int(coefficient != 0)
    return counts


def lasso_selection(formula):
    counts = term_counts(formula)
    total = sum(row[0] for row in counts.values())
    retained = sum(row[1] for row in counts.values())
    fig, ax = plt.subplots(figsize=(7.2, 3.6), layout="constrained")
    colors = [COLORS[0], COLORS[2], COLORS[1]]
    for i, ((label, (before, after)), color) in enumerate(zip(counts.items(), colors)):
        ax.barh(i, before, height=.42, color="#E8EDF3", zorder=2)
        ax.barh(i, after, height=.42, color=color, zorder=3)
        ax.text(after / 2, i, str(after), ha="center", va="center",
                 color="white", fontweight="bold", fontsize=11)
        ax.text(before + 1.2, i, f"{before} → {after}", va="center", color="#344256", fontsize=11)
    ax.set_yticks(range(3), counts.keys(), fontsize=11)
    ax.set(xlabel="模型项数", xlim=(0, 54), ylim=(2.55, -.7), xticks=range(0, 51, 10))
    ax.set_title(f"{total} 个候选项  →  {retained} 个非零项", loc="left", fontsize=13, pad=18)
    ax.legend(handles=[Patch(facecolor="#E8EDF3", label=f"系数为零：{total-retained} 项")],
               loc="upper right", bbox_to_anchor=(1, 1.19), fontsize=9)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0, pad=12)
    light_grid(ax, "x")
    return fig


def ale_curve(model, x, column, bins=20):
    edges = np.unique(np.quantile(x[:, column], np.linspace(0, 1, bins + 1)))
    membership = np.clip(np.searchsorted(edges, x[:, column], side="right") - 1, 0, len(edges)-2)
    increments = []
    for b in range(len(edges)-1):
        subset = x[membership == b].copy()
        lower, upper = subset.copy(), subset.copy()
        lower[:, column], upper[:, column] = edges[b], edges[b+1]
        change = model.predict(upper).reshape(-1) - model.predict(lower).reshape(-1)
        increments.append(float(change.mean()))
    values = np.r_[0, np.cumsum(increments)]
    values -= np.interp(x[:, column], edges, values).mean()
    return edges, values


def draw_all(config, output):
    style()
    folder = ROOT / "figures"
    folder.mkdir(exist_ok=True)
    manifest = []

    def save(fig, number, title, description, panels):
        name = f"q2_{number}"
        for extension in ["png", "svg"]:
            fig.savefig(folder / f"{name}.{extension}", dpi=config["visualization"]["dpi"], bbox_inches="tight")
        manifest.append(dict(number=number, title=title, caption=title, description=description, panels=panels,
                             png=f"../figures/{name}.png", svg=f"../figures/{name}.svg"))
        plt.close(fig)
        print("FIGURE", number, title, flush=True)

    _, x, y = read_data(ROOT / config["data"]["train"])
    frame = pd.DataFrame(x, columns=NAMES)
    frame["monthly_rent"] = y
    fig, ax = axes_pair()
    ax[0].hist(y, bins=35, color=COLORS[0], alpha=.88, edgecolor="white", linewidth=.6)
    ax[0].axvline(np.median(y), color=COLORS[2], lw=1.6, label=f"中位数 {np.median(y):.0f}")
    ax[0].set(xlabel="月租金（元/月）", ylabel="房源数", title="租金分布")
    ax[0].legend()
    image = ax[1].hexbin(x[:, 0], y, gridsize=32, mincnt=1, cmap="YlGnBu", linewidths=.15)
    fig.colorbar(image, ax=ax[1], label="房源数", shrink=.82, pad=.02)
    ax[1].set(xlabel="建筑面积（m²）", ylabel="月租金（元/月）", title="面积与租金")
    save(fig, "01", "训练样本的租金分布与面积关系",
         f"训练集月租金中位数为 {np.median(y):.2f} 元/月，分布较对称。面积与租金呈明显正相关，但同一面积仍对应不同租金，说明需要联合使用其他特征。", 2)

    order = [0, 4, 1, 5, 8, 7, 9, 2, 3, 6, 10]
    corr = frame.corr().to_numpy()[np.ix_(order, order)]
    labels = np.array(LABELS + ["月租金"])[order]
    shown = np.ma.masked_where(np.triu(np.ones_like(corr), 1).astype(bool), corr)
    fig, ax = plt.subplots(figsize=(6.6, 5.2), layout="constrained")
    image = ax.imshow(shown, cmap="RdBu_r", vmin=-1, vmax=1)
    ax.set_xticks(range(11), labels, rotation=45, ha="right", fontsize=9)
    ax.set_yticks(range(11), labels, fontsize=9)
    for i in range(11):
        for j in range(i):
            if abs(corr[i, j]) >= .55:
                ax.text(j, i, f"{corr[i,j]:.2f}", ha="center", va="center", fontsize=9,
                        color="white" if abs(corr[i,j]) > .7 else "#24354A")
    ax.set_xticks(np.arange(-.5, 11, 1), minor=True)
    ax.set_yticks(np.arange(-.5, 11, 1), minor=True)
    ax.grid(which="minor", color="white", linewidth=2)
    ax.tick_params(which="minor", bottom=False, left=False)
    fig.colorbar(image, ax=ax, shrink=.72, label="Pearson 相关系数", pad=.03)
    save(fig, "02", "特征之间及其与租金的相关性",
         "面积与卧室数、两类距离及配套数之间存在较强相关性。这为正则化与降维实验提供了依据，但相关性不能单独决定删留特征，也不能解释为因果关系。", 1)

    fig, ax = axes_pair()
    groups = np.clip(((x[:, 5]-1) // 7).astype(int), 0, 3)
    for elevator, color in zip([0, 1], [COLORS[2], COLORS[0]]):
        values = [y[(groups == g) & (x[:, 8] == elevator)] for g in range(4)]
        quantiles = np.array([np.quantile(v, [.25, .5, .75]) for v in values])
        ax[0].plot(range(4), quantiles[:, 1], "o-", color=color, label="有电梯" if elevator else "无电梯")
        ax[0].fill_between(range(4), quantiles[:, 0], quantiles[:, 2], color=color, alpha=.13)
    ax[0].set_xticks(range(4), ["1–7", "8–14", "15–21", "22–28"])
    ax[0].set(xlabel="楼层分组（层）", ylabel="月租金（元/月）", title="楼层与电梯的分组关系")
    ax[0].legend(loc="upper left", fontsize=8)
    values = [y[x[:, 7] == k] for k in range(1, 6)]
    boxes = ax[1].boxplot(values, patch_artist=True, showfliers=False, widths=.6,
                         medianprops=dict(color="#344256", linewidth=1.5),
                         whiskerprops=dict(color="#8D9DAF"), capprops=dict(color="#8D9DAF"))
    for box, color in zip(boxes["boxes"], plt.cm.YlGnBu(np.linspace(.25, .8, 5))):
        box.set(facecolor=color, edgecolor="white", alpha=.85)
    ax[1].set(xlabel="装修评分", ylabel="月租金（元/月）", title="不同装修评分的租金")
    for a in ax:
        light_grid(a)
    save(fig, "03", "楼层、电梯及装修条件的分组分布",
         "左图为分组中位数及四分位区间，右图为装修评分对应的租金箱线图。组内离散程度仍较大，因此这些现象仅用于提出交互和编码假设，是否有效还需交叉验证。箱线图未显示离群点标记，训练样本均保留。", 2)

    if (output / "pca.npz").exists():
        data = np.load(output / "pca.npz")
        comparison = pd.read_csv(output / "comparison.csv")
        fig = pca_analysis(data, comparison)
        var2 = data["variance"][:2].sum() * 100
        var9 = data["variance"][:9].sum() * 100
        scores = comparison.set_index("candidate").rmse
        save(fig, "04", "PCA 方差保留与降维回归的预测表现",
             f"左图显示累计解释方差：前两个成分保留 {var2:.2f}%，九个成分已保留 {var9:.2f}%。"
             f"右图中，PCA 回归保留九个成分时的验证 RMSE 仍为 {scores['dimension:pcr:9']:.2f} 元/月，"
             f"全部十个成分时才降至 {scores['dimension:pcr:10']:.2f} 元/月，接近原始 OLS。"
             "这说明保留大部分输入变化不等于保留全部预测信息，输入方差较小的方向也可能有用。"
             "PLS 利用训练租金寻找方向，用较少成分即可接近原始线性模型，但没有明显降低其预测误差。\n\n"
             "左图使用固定的 3,000 条训练子样本作描述性分析；右图使用全部 7,500 条训练记录的五折外层验证，"
             "各折分别拟合预处理与降维，阴影表示折间标准差。PCA 回归在内层选择 OLS 或 Ridge 及惩罚强度；"
             "左右图不共用一个拟合好的 PCA，方差比例也不用于替代预测验证。", 2)
        norm = Normalize(vmin=float(data["y"].min()), vmax=float(data["y"].max()))
        fig, ax = plt.subplots(figsize=(6, 4.1), layout="constrained")
        points = ax.scatter(data["scores"][:, 0], data["scores"][:, 1], c=data["y"], cmap="viridis",
                            norm=norm, s=8, alpha=.8, linewidths=0, rasterized=True)
        ax.set(xlabel="第一主成分 PC1", ylabel="第二主成分 PC2")
        fig.colorbar(points, ax=ax, label="月租金（元/月）", shrink=.85)
        save(fig, "05", "PCA 二维投影中的租金分布",
             "颜色表示租金，坐标仅由房源特征决定。投影可用于观察整体结构和租金梯度，但二维重叠不意味着原始空间的特征没有预测价值。", 1)
        files = [output / "embeddings" / "tsne_42_30.npz", output / "embeddings" / "umap_42_30_0.1.npz"]
        if all(p.exists() for p in files):
            elevator = x[data["sample"], NAMES.index("has_elevator")]
            fig = embedding_comparison(data, files, elevator, norm)
            counts = [int(np.sum(elevator == value)) for value in [0, 1]]
            medians = [float(np.median(data["y"][elevator == value])) for value in [0, 1]]
            save(fig, "06", "t-SNE 与 UMAP 投影中的电梯分组和租金分布",
                 f"两图使用相同的 3,000 条训练房源，其中无电梯 {counts[0]:,} 套、有电梯 {counts[1]:,} 套。"
                 "标签来自真实电梯字段，数量统计整个子样本中的该类房源；引线指向各类坐标的中位位置，"
                 "并不表示算法识别出的聚类边界。t-SNE 的左上区域与无电梯房源对应，右下区域主要为有电梯房源；"
                 "UMAP 也呈现相近分区，但有少量交叠，不能将分区视为完全分离的类别。\n\n"
                 f"共用色标显示每个电梯组内部仍有明显的租金变化；无电梯、有电梯组的租金中位数分别为 "
                 f"{medians[0]:.2f}、{medians[1]:.2f} 元/月。电梯状态只能解释部分样本结构，不能单独决定租金，"
                 "组间差异也可能同时反映面积、楼层等属性。租金仅在投影完成后着色，未参与降维拟合；"
                 "这两种投影没有用于筛选最终多项式项，也不以点云分离程度判断预测精度。"
                 "为适应版面，UMAP 显示坐标整体旋转了 35°，未改变点间距离；两图均采用等比例坐标，未拉伸点云。", 2)

    if (output / "comparison.csv").exists():
        comparison = pd.read_csv(output / "comparison.csv")
        folds = pd.read_csv(output / "fold_metrics.csv")
        coef = json.loads((output / "fold_coefficients.json").read_text(encoding="utf-8"))
        fig, ax = axes_pair()
        best = []
        for family in FAMILY_LABEL:
            subset = comparison[comparison.candidate.str.startswith(f"{family}:")]
            best.append(subset.loc[subset.rmse.idxmin()])
        best = pd.DataFrame(best).sort_values("rmse", ascending=False)
        ax[0].errorbar(best.rmse, range(len(best)), xerr=best.rmse_std, fmt="o", color=COLORS[0],
                       ecolor="#B5C9E1", capsize=3)
        ax[0].set_yticks(range(len(best)), best.family.map(FAMILY_LABEL), fontsize=9)
        ax[0].set(xlabel="RMSE（元/月）", title="每类方案的最低外层误差")
        full_key = "ablation:" + "+".join(BLOCKS)
        full = folds[folds.candidate == full_key].sort_values("fold").rmse.to_numpy()
        for i, block in enumerate(BLOCKS):
            key = "ablation:" + "+".join(b for b in BLOCKS if b != block)
            without = folds[folds.candidate == key].sort_values("fold").rmse.to_numpy()
            diff = without-full
            ax[1].errorbar(diff.mean(), i, xerr=diff.std(ddof=1), fmt="o", color=COLORS[2], capsize=3)
        ax[1].axvline(0, color="#9AA7B8", ls="--", lw=1)
        ax[1].set_yticks(range(4), ["移除"+BLOCK_LABEL[b] for b in BLOCKS], fontsize=9)
        ax[1].set(xlabel="RMSE 增量（元/月）", title="组合特征消融 · 固定 Ridge")
        for a in ax:
            light_grid(a, "x")
        save(fig, "07", "特征方案比较与组合特征消融",
             "左图展示各特征方案的最低平均外层 RMSE；右图比较移除某一组派生特征后，相对于完整组合的配对 RMSE 变化。增量为正表示移除后变差。误差线为折间标准差，不能解释为显著性检验。", 2)

        fig, ax = axes_pair()
        methods = ["ols", "ridge", "lasso", "elastic"]
        for shift, family, color in [(-.1, "raw", COLORS[0]), (.1, "domain", COLORS[1])]:
            rows = comparison.set_index("candidate").loc[[f"{family}:{m}" for m in methods]]
            ax[0].errorbar(np.arange(4)+shift, rows.rmse, yerr=rows.rmse_std, fmt="o-", color=color,
                           label=FAMILY_LABEL[family], capsize=2, lw=1)
        ax[0].set_xticks(range(4), ["OLS", "Ridge", "Lasso", "EN"], fontsize=9)
        ax[0].set(ylabel="RMSE（元/月）", title="不同惩罚的验证表现")
        ax[0].legend(fontsize=8)
        light_grid(ax[0])
        weights = np.array([np.mean([r["standardized_coefficients"] for r in coef[f"raw:{m}"]], axis=0) for m in methods]).T
        limit = np.abs(weights).max()
        image = ax[1].imshow(weights, cmap="RdBu_r", vmin=-limit, vmax=limit, aspect="auto")
        ax[1].set_yticks(range(10), LABELS, fontsize=8)
        ax[1].set_xticks(range(4), ["OLS", "Ridge", "Lasso", "EN"], fontsize=8)
        ax[1].set_title("原始特征的平均系数")
        fig.colorbar(image, ax=ax[1], label="元/月 · 每标准差", shrink=.82, pad=.02)
        save(fig, "08", "正则化的预测表现与系数变化",
             "左图比较原始特征和内层选择后的组合特征，误差线为五折标准差。右图为原始特征模型的折间平均标准化系数，反映方向和量级。惩罚强度均独立调优，不把相同 alpha 解释为相同惩罚。", 2)

    if (output / "final_metrics.json").exists():
        model = joblib.load(output / "final_model.joblib")
        final = json.loads((output / "final_metrics.json").read_text(encoding="utf-8"))
        pred = pd.read_csv(output / "test_predictions.csv")
        formula = json.loads((output / "final_formula.json").read_text(encoding="utf-8"))
        counts = term_counts(formula)
        total = sum(row[0] for row in counts.values())
        retained = sum(row[1] for row in counts.values())
        transitions = "、".join(f"{label} {before}→{after}" for label, (before, after) in counts.items())
        fig = lasso_selection(formula)
        save(fig, "09", "Lasso 对二次候选项的筛选结果",
             f"图中每根条的总长度表示该类候选项数，彩色部分表示最终非零项，浅灰部分表示系数为零的项。"
             f"具体为{transitions}，共由 {total} 项减少为 {retained} 项，另有 {total-retained} 项系数为零。"
             "候选集中未重复加入电梯平方项，因为二元电梯变量的平方等于自身。\n\n"
             "这些数量来自全训练集上已锁定模型的实际系数，截距不计入项数。Lasso 同时拟合全部候选项，"
             "在交叉验证选定的惩罚强度下使部分系数变为零，并未预先指定保留 30 项，也不是按系数大小截取前 30 项。"
             "电梯一次项虽被置零，仍通过交互项参与预测；因此，30 个模型项不能理解为 30 个原始变量。"
             "该图说明公式如何简化，不把项数或保留比例解释为变量的重要性。", 1)
        fig, ax = axes_pair()
        for a, j, xlabel, color in zip(ax, [0, 2], ["建筑面积（m²）", "地铁距离（km）"], COLORS):
            edges, effects = ale_curve(model, x, j)
            a.fill_between(edges, 0, effects, color=color, alpha=.13)
            a.plot(edges, effects, color=color, lw=2)
            a.axhline(0, color="#AAB5C2", lw=.8, ls="--")
            a.set(xlabel=xlabel, ylabel="预测租金变化（元/月）", title=LABELS[j]+"的局部平均影响")
            a.plot(np.quantile(x[:, j], np.linspace(0, 1, 11)), np.full(11, .02), "|", color=color,
                   transform=a.get_xaxis_transform(), markersize=5)
            light_grid(a)
        save(fig, "10", "最终模型的局部平均影响曲线",
             "曲线依据 20 个分位数区间内的局部预测差异累积并中心化，底部短线表示特征分位位置。纵轴反映模型预测随特征变化的相对增减，减少远离真实房源组合的替换；它不是因果效应。", 2)

        fig, ax = plt.subplots(figsize=(6, 4.3), layout="constrained")
        image = ax.hexbin(pred.actual_rent, pred.predicted_rent, gridsize=35, mincnt=1,
                          cmap="YlGnBu", linewidths=.15)
        low = min(pred.actual_rent.min(), pred.predicted_rent.min())-100
        high = max(pred.actual_rent.max(), pred.predicted_rent.max())+100
        ax.plot([low, high], [low, high], color="#66778D", ls="--", lw=1.2, label="预测 = 实际")
        ax.set(xlabel="实际月租金（元/月）", ylabel="预测月租金（元/月）", xlim=(low, high), ylim=(low, high))
        ax.set_aspect("equal", adjustable="box")
        ax.legend(loc="upper left")
        fig.colorbar(image, ax=ax, label="房源数", shrink=.85)
        save(fig, "11", "测试集实际租金与最终预测",
             f"对全部 1,500 条测试房源，最终模型的 RMSE 为 {final['test']['rmse']:.2f} 元/月，MAE 为 {final['test']['mae']:.2f} 元/月，R² 为 {final['test']['r2']:.4f}。参考线上的点表示预测与实际一致。", 1)

        fig, ax = axes_pair()
        residual = pred.residual.to_numpy()
        ax[0].hist(residual, bins=32, color=COLORS[1], alpha=.85, edgecolor="white", linewidth=.5)
        ax[0].axvline(0, color="#52647B", ls="--", lw=1)
        ax[0].axvline(residual.mean(), color=COLORS[2], lw=1.5, label=f"均值 {residual.mean():.1f}")
        ax[0].set(xlabel="残差：实际 − 预测（元/月）", ylabel="房源数", title="误差分布")
        ax[0].legend(fontsize=8)
        ax[1].hexbin(pred.predicted_rent, residual, gridsize=27, mincnt=1, cmap="Blues", linewidths=.1)
        ax[1].axhline(0, color=COLORS[2], ls="--", lw=1.2)
        ax[1].set(xlabel="预测月租金（元/月）", ylabel="残差（元/月）", title="误差与租金水平")
        save(fig, "12", "最终模型的测试残差诊断",
             f"残差定义为实际租金减预测租金，正值表示低估。测试残差均值为 {residual.mean():.2f} 元/月。两图用于检查整体偏向、尾部误差及误差是否随租金水平变化；测试诊断不再用于调参。", 2)

    if (output / "embedding_stability.json").exists():
        embedding = pd.read_csv(output / "embedding_metrics.csv")
        stability = pd.DataFrame(json.loads((output / "embedding_stability.json").read_text(encoding="utf-8")))
        fig, ax = axes_pair()
        for i, method in enumerate(["tsne", "umap"]):
            values = embedding[embedding.method == method].trustworthiness.to_numpy()
            ax[0].scatter(np.linspace(i-.14, i+.14, len(values)), values, color=COLORS[i], s=20, alpha=.65)
            ax[0].plot([i-.2, i+.2], [values.mean()]*2, color=COLORS[i], lw=2)
        groups = [(stability.method == "tsne") & (stability["init"] == "pca"),
                  (stability.method == "tsne") & (stability["init"] == "random"),
                  stability.method == "umap"]
        for i, (group, color) in enumerate(zip(groups, [COLORS[0], COLORS[3], COLORS[1]])):
            values = stability[group].overlap.to_numpy()
            ax[1].scatter(np.linspace(i-.14, i+.14, len(values)), values, color=color, s=20, alpha=.65)
            ax[1].plot([i-.2, i+.2], [values.mean()]*2, color=color, lw=2)
        ax[0].set_xticks([0, 1], ["t-SNE", "UMAP"])
        ax[1].set_xticks([0, 1, 2], ["t-SNE\nPCA 初始", "t-SNE\n随机初始", "UMAP"], fontsize=8)
        for a in ax:
            light_grid(a)
        ax[0].set(ylabel="Trustworthiness（k = 15）", title="不同设置的邻域保持")
        ax[1].set(ylabel="二维近邻重合比例", title="改变随机种子的稳定性")
        save(fig, "S1", "降维方法的参数与随机种子敏感性",
             f"左图汇总 {len(embedding)} 组投影的邻域保持指标，右图比较更换种子后的二维近邻重合比例，并区分 t-SNE 的 PCA 与随机初始化。横线为各组均值；指标衡量局部结构，不衡量租金预测准确率。", 2)

    raw_search = output / "fold_1" / "raw_search.json"
    if raw_search.exists() and (output / "fold_coefficients.json").exists():
        records = json.loads(raw_search.read_text(encoding="utf-8"))["records"]
        fig, ax = axes_pair()
        for a, method, color in zip(ax, ["ridge", "lasso"], COLORS):
            rows = [r for r in records if r["valid"] and r["params"].get("model__kind") == method]
            rows.sort(key=lambda r: r["params"]["model__alpha"])
            alpha = [r["params"]["model__alpha"] for r in rows]
            a.semilogx(alpha, [r["rmse"] for r in rows], "o-", color=color, ms=3, label="内层验证")
            a.semilogx(alpha, [r["train_rmse"] for r in rows], "--", color="#A3AFBF", label="内层训练")
            a.set(xlabel="alpha（该方法的定义）", ylabel="RMSE（元/月）", title=METHOD_LABEL[method])
            a.legend(fontsize=8)
            light_grid(a)
        save(fig, "S2", "Ridge 与 Lasso 的正则强度曲线",
             "以第一外层折的训练部分为例，展示三折内层训练及验证误差。其他外层折独立执行相同搜索。横轴分别遵循各算法的 alpha 定义，不能跨方法直接比较惩罚强弱。", 2)
        fig, ax = axes_pair()
        for rho, color in zip([.1, .5, .9], COLORS):
            rows = [r for r in records if r["valid"] and r["params"].get("model__kind") == "elastic"
                    and r["params"].get("model__l1_ratio") == rho]
            rows.sort(key=lambda r: r["params"]["model__alpha"])
            ax[0].semilogx([r["params"]["model__alpha"] for r in rows], [r["rmse"] for r in rows],
                           color=color, label=f"L1 比例 {rho}")
        ax[0].set(xlabel="Elastic Net alpha", ylabel="内层验证 RMSE（元/月）", title="混合比例与正则强度")
        ax[0].legend(fontsize=8)
        coeff = json.loads((output / "fold_coefficients.json").read_text(encoding="utf-8"))
        spread = []
        for method in ["ols", "ridge", "lasso", "elastic"]:
            matrix = np.array([r["standardized_coefficients"] for r in coeff[f"raw:{method}"]])
            spread.append(matrix.std(axis=0, ddof=1))
        weights = np.array(spread).T
        im = ax[1].imshow(weights, cmap="YlGnBu", aspect="auto")
        ax[1].set_yticks(range(10), LABELS, fontsize=8)
        ax[1].set_xticks(range(4), ["OLS", "Ridge", "Lasso", "EN"], fontsize=8)
        ax[1].set_title("标准化系数的折间波动")
        fig.colorbar(im, ax=ax[1], label="标准差（元/月）", shrink=.82, pad=.02)
        save(fig, "S3", "Elastic Net 调参与系数稳定性",
             "左图沿用第一外层折的内层验证设置，比较三个 L1 比例；右图为原始特征模型五折标准化系数的标准差。较小波动代表在本次划分下更稳定，不等同于因果解释更可靠。", 2)
    save_json(output / "figures.json", manifest)
