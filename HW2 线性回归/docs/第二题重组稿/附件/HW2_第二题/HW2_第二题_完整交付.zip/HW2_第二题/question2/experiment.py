"""共享折划分的嵌套验证。测试集只在模型锁定后读取标签。"""

import hashlib
import json
import time
import warnings
from importlib.metadata import version
import joblib
import numpy as np
import pandas as pd
from sklearn.base import clone
from sklearn.cross_decomposition import PLSRegression
from sklearn.decomposition import PCA
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from sklearn.model_selection import GridSearchCV, KFold
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import StandardScaler
from threadpoolctl import threadpool_limits
from . import ROOT
from .features import FeatureMap, CheckedLinear, BLOCKS, NAMES, read_data, export_formula, save_json

FAMILIES = ["raw", "encoded", "domain", "quadratic", "spline", "pcr", "pls"]
METHODS = ["ols", "ridge", "lasso", "elastic"]


def metrics(y, pred):
    return dict(rmse=float(np.sqrt(mean_squared_error(y, pred))),
                mae=float(mean_absolute_error(y, pred)), r2=float(r2_score(y, pred)))


def pipeline_for(family):
    kind = "raw" if family in {"pcr", "pls"} else family
    steps = [("features", FeatureMap(kind)), ("scale", StandardScaler())]
    if family == "pcr":
        steps.append(("pca", PCA(svd_solver="full")))
    model = PLSRegression(scale=False) if family == "pls" else CheckedLinear()
    return Pipeline(steps + [("model", model)])


def domain_variants():
    variants = [tuple([b]) for b in BLOCKS] + [BLOCKS]
    variants += [tuple(b for b in BLOCKS if b != removed) for removed in BLOCKS]
    return variants


def search_grids(family, config):
    settings = config["search"]
    feature = {}
    if family == "encoded":
        feature["features__categories"] = [(4,), (7,), (4, 7)]
    elif family == "domain":
        feature["features__blocks"] = domain_variants()
    elif family == "spline":
        feature["features__knots"] = settings["knots"]
    elif family == "pcr":
        feature["pca__n_components"] = settings["components"]
    elif family == "pls":
        return [{"model__n_components": settings["components"]}]
    lo, hi, count = settings["lasso_exponents"]
    sparse_alpha = np.logspace(lo, hi, count).tolist()
    grids = []
    for method in (["ols", "ridge"] if family == "pcr" else METHODS):
        grid = dict(feature, model__kind=[method])
        if method != "ols":
            grid["model__alpha"] = settings["ridge"] if method == "ridge" else sparse_alpha
        if method == "elastic":
            grid["model__l1_ratio"] = settings["l1_ratio"]
        grids.append(grid)
    return grids


def grid_records(pipeline, grids, x, y, cv, jobs):
    search = GridSearchCV(pipeline, grids, scoring="neg_root_mean_squared_error", cv=cv,
                          n_jobs=jobs, refit=False, return_train_score=True, error_score=np.nan)
    with warnings.catch_warnings(record=True) as caught:
        warnings.simplefilter("always")
        search.fit(x, y)
    records = []
    for i, params in enumerate(search.cv_results_["params"]):
        valid = np.isfinite(search.cv_results_["mean_test_score"][i])
        records.append(dict(params=params, valid=bool(valid),
                            rmse=float(-search.cv_results_["mean_test_score"][i]) if valid else None,
                            train_rmse=float(-search.cv_results_["mean_train_score"][i]) if valid else None))
    return records, [str(w.message) for w in caught]


def tune(family, x, y, cv, config, destination):
    grids = search_grids(family, config)
    pipeline = pipeline_for(family)
    records, messages = grid_records(pipeline, grids, x, y, cv, config["validation"]["jobs"])
    extensions = []
    # 分别检查每种惩罚的最佳值，扩展搜索仍只使用内层训练/验证数据。
    for grid in grids:
        if "model__alpha" not in grid:
            continue
        method = grid["model__kind"][0]
        subset = [r for r in records if r["valid"] and r["params"].get("model__kind") == method]
        best = min(subset, key=lambda r: r["rmse"])
        value = best["params"]["model__alpha"]
        low, high = min(grid["model__alpha"]), max(grid["model__alpha"])
        if value not in {low, high}:
            continue
        step = 1 if method == "ridge" else 0.5
        offsets = np.arange(step, 2 + step / 2, step)
        values = value * (10 ** (offsets if value == high else -offsets))
        expanded = dict(grid, model__alpha=values.tolist())
        more, caught = grid_records(pipeline, [expanded], x, y, cv, config["validation"]["jobs"])
        records.extend(more)
        messages.extend(caught)
        extensions.append(dict(method=method, boundary=value, added=values.tolist()))
    save_json(destination, dict(records=records, warnings=messages, extensions=extensions))
    return records


def best_record(records, **conditions):
    subset = [r for r in records if r["valid"] and all(r["params"].get(k) == v for k, v in conditions.items())]
    return min(subset, key=lambda r: r["rmse"])


def audit(config, output):
    path = ROOT / config["data"]["train"]
    ids, x, y = read_data(path)
    frame = pd.DataFrame(x, columns=NAMES)
    frame["monthly_rent"] = y
    frame.describe().T.to_csv(output / "descriptive.csv", encoding="utf-8-sig")
    frame.corr().to_csv(output / "correlations.csv", encoding="utf-8-sig")
    quality = dict(rows=len(y), predictors=x.shape[1], missing=int(frame.isna().sum().sum()),
                   duplicate_features=int(pd.DataFrame(x).duplicated().sum()),
                   target_skew=float(pd.Series(y).skew()), log_target_skew=float(pd.Series(np.log(y)).skew()),
                   no_elevator_high_floor=int(((x[:, 8] == 0) & (x[:, 5] >= 10)).sum()))
    save_json(output / "audit.json", quality)
    packages = ["numpy", "scipy", "pandas", "scikit-learn", "matplotlib", "PyYAML", "umap-learn", "numba"]
    provenance = dict(packages={p: version(p) for p in packages},
                      data_sha256={name: hashlib.sha256((ROOT / p).read_bytes()).hexdigest()
                                   for name, p in config["data"].items()})
    save_json(output / "environment.json", provenance)


def compare(config, output):
    ids, x, y = read_data(ROOT / config["data"]["train"])
    validation = config["validation"]
    folds = list(KFold(validation["outer_folds"], shuffle=True,
                       random_state=validation["outer_seed"]).split(x))
    save_json(output / "folds.json", [dict(train=a, valid=b) for a, b in folds])
    rows, predictions, coefficients = [], {}, {}
    for fold, (train, valid) in enumerate(folds):
        fold_dir = output / f"fold_{fold + 1}"
        fold_dir.mkdir(exist_ok=True)
        inner = list(KFold(validation["inner_folds"], shuffle=True,
                           random_state=validation["inner_seed"]).split(x[train]))
        save_json(fold_dir / "inner_folds.json", [dict(train=a, valid=b) for a, b in inner])
        for family in FAMILIES:
            start = time.time()
            destination = fold_dir / f"{family}_search.json"
            if destination.exists():
                records = json.loads(destination.read_text(encoding="utf-8"))["records"]
                # JSON 数组恢复为 sklearn 参数所需的不可变特征组。
                for r in records:
                    for key in ["features__categories", "features__blocks"]:
                        if key in r["params"]:
                            r["params"][key] = tuple(r["params"][key])
            else:
                records = tune(family, x[train], y[train], inner, config, destination)
            selections = {}
            methods = ["pls"] if family == "pls" else (["ols", "ridge"] if family == "pcr" else METHODS)
            for method in methods:
                filters = {} if method == "pls" else {"model__kind": method}
                selections[f"{family}:{method}"] = best_record(records, **filters)
            if family in {"pcr", "pls"}:
                key = "pca__n_components" if family == "pcr" else "model__n_components"
                for k in config["search"]["components"]:
                    selections[f"dimension:{family}:{k}"] = best_record(records, **{key: k})
            if family == "domain":
                for blocks in domain_variants():
                    key = "ablation:" + "+".join(blocks)
                    selections[key] = best_record(records, model__kind="ridge", features__blocks=blocks)
            for key, record in selections.items():
                model = pipeline_for(family).set_params(**record["params"]).fit(x[train], y[train])
                prediction = model.predict(x[valid]).reshape(-1)
                formula = export_formula(model)
                nonzero = np.count_nonzero(np.abs(formula["standardized_coefficients"]) > 1e-8)
                row = dict(candidate=key, family=family, fold=fold + 1, nonzero=int(nonzero),
                           train_rmse=metrics(y[train], model.predict(x[train]).reshape(-1))["rmse"],
                           params=json.dumps(record["params"], ensure_ascii=False), **metrics(y[valid], prediction))
                rows.append(row)
                predictions.setdefault(key, np.zeros(len(y)))[valid] = prediction
                coefficients.setdefault(key, []).append(formula)
            print(f"fold={fold+1} {family:10s} candidates={len(records):4d} seconds={time.time()-start:.1f}", flush=True)
        key = "mean:mean"
        pred = np.full(len(valid), y[train].mean())
        predictions.setdefault(key, np.zeros(len(y)))[valid] = pred
        rows.append(dict(candidate=key, family="mean", fold=fold+1, nonzero=0, params="{}",
                         train_rmse=float(y[train].std()), **metrics(y[valid], pred)))
        pd.DataFrame(rows).to_csv(output / "fold_metrics.csv", index=False, encoding="utf-8-sig")
    np.savez_compressed(output / "oof_predictions.npz", listing_id=ids, y=y, **predictions)
    save_json(output / "fold_coefficients.json", coefficients)
    frame = pd.DataFrame(rows)
    summary = frame.groupby(["candidate", "family"]).agg(
        rmse=("rmse", "mean"), rmse_std=("rmse", "std"), mae=("mae", "mean"),
        r2=("r2", "mean"), nonzero=("nonzero", "mean"), train_rmse=("train_rmse", "mean")).reset_index()
    summary.to_csv(output / "comparison.csv", index=False, encoding="utf-8-sig")
    eligible = summary[~summary.candidate.str.startswith(("dimension:", "ablation:", "mean:"))].copy()
    best = eligible.loc[eligible.rmse.idxmin()]
    threshold = best.rmse + best.rmse_std / np.sqrt(len(folds))
    rank = {"raw": 0, "pcr": 0, "pls": 0, "encoded": 1, "domain": 1, "quadratic": 2, "spline": 3}
    shortlist = eligible[eligible.rmse <= threshold].copy()
    shortlist["complexity"] = shortlist.family.map(rank)
    chosen = shortlist.sort_values(["complexity", "nonzero", "rmse", "candidate"]).iloc[0]
    save_json(output / "selection.json", dict(lowest_rmse=best.candidate, selected=chosen.candidate,
              threshold=float(threshold), eligible=shortlist.candidate.tolist(), test_used=False))
    print("SELECTED", chosen.candidate, "LOWEST", best.candidate, flush=True)


def finalize(config, output):
    if (output / "final_metrics.json").exists():
        print("Final evaluation already exists; use saved results.", flush=True)
        return
    selection = json.loads((output / "selection.json").read_text(encoding="utf-8"))
    family, method = selection["selected"].split(":")
    ids, x, y = read_data(ROOT / config["data"]["train"])
    cv = list(KFold(5, shuffle=True, random_state=2026).split(x))
    records = tune(family, x, y, cv, config, output / "final_search.json")
    filters = {} if method == "pls" else {"model__kind": method}
    record = best_record(records, **filters)
    model = pipeline_for(family).set_params(**record["params"]).fit(x, y)
    formula = export_formula(model)
    joblib.dump(model, output / "final_model.joblib")
    save_json(output / "final_formula.json", formula)
    save_json(output / "model_lock.json", dict(candidate=selection["selected"], params=record["params"],
              model_sha256=hashlib.sha256((output / "final_model.joblib").read_bytes()).hexdigest()))
    # 模型与参数已经锁定，现在才进入测试评价。
    test_ids, x_test, y_test = read_data(ROOT / config["data"]["test"])
    if set(ids) & set(test_ids):
        raise ValueError("训练集与测试集编号重叠。")
    prediction = model.predict(x_test).reshape(-1)
    pd.DataFrame(dict(listing_id=test_ids, actual_rent=y_test, predicted_rent=prediction,
                      residual=y_test-prediction)).to_csv(output / "test_predictions.csv", index=False,
                                                        encoding="utf-8-sig", float_format="%.10f")
    result = dict(train=metrics(y, model.predict(x).reshape(-1)), test=metrics(y_test, prediction),
                  inner_cv_rmse=record["rmse"], test_rows=len(y_test))
    save_json(output / "final_metrics.json", result)
    print("FINAL", result, flush=True)


def run_training(config, output, stage):
    with threadpool_limits(limits=1):
        if stage in {"all", "compare"}:
            audit(config, output)
            compare(config, output)
        if stage in {"all", "finalize"}:
            finalize(config, output)
