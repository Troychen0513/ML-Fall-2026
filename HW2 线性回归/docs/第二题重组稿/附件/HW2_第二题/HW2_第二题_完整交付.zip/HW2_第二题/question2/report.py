"""从已保存的实验记录生成正文、数学表达式、插图和完整源码。"""

import hashlib
import json
import numpy as np
import pandas as pd
from . import ROOT
from .features import NAMES, LABELS, BLOCKS, read_data, save_json
from .plot import FAMILY_LABEL, METHOD_LABEL, BLOCK_LABEL


def table(headers, rows):
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in rows:
        lines.append("| " + " | ".join(str(v) for v in row) + " |")
    return "\n".join(lines)


def term_math(name):
    tokens = []
    for part in name.split(" "):
        base, *power = part.split("^")
        j = NAMES.index(base) + 1
        token = "x_{" + str(j) + "}"
        if power:
            token += "^{" + power[0] + "}"
        tokens.append(token)
    return " ".join(tokens)


def polynomial_expression(formula):
    terms = []
    for name, value in zip(formula["names"], formula["coefficients"]):
        if value == 0:
            continue
        sign = "+" if value > 0 else "-"
        terms.append(f"{sign}{abs(value):.10g}" + term_math(name))
    lines = [r"\begin{aligned}", r"\hat y={}&" + f"{formula['intercept']:.10g}" + " ".join(terms[:2]) + r"\\"]
    for start in range(2, len(terms), 3):
        suffix = r"\\" if start + 3 < len(terms) else ""
        lines.append("&" + " ".join(terms[start:start+3]) + suffix)
    lines.append(r"\end{aligned}")
    return "$$\n" + "\n".join(lines) + "\n$$"


def build_report(config, output):
    load = lambda name: json.loads((output / name).read_text(encoding="utf-8"))
    comparison = pd.read_csv(output / "comparison.csv")
    folds = pd.read_csv(output / "fold_metrics.csv")
    formula, final, selection = load("final_formula.json"), load("final_metrics.json"), load("selection.json")
    locked, audit = load("model_lock.json"), load("audit.json")
    figures = {r["number"]: r for r in load("figures.json")}
    pred = pd.read_csv(output / "test_predictions.csv")
    _, x, y = read_data(ROOT / config["data"]["train"])
    test_ids, test_x, test_y = read_data(ROOT / config["data"]["test"])
    eligible = comparison[~comparison.candidate.str.startswith(("dimension:", "ablation:"))].copy()
    by_key = comparison.set_index("candidate")
    chosen = by_key.loc[selection["selected"]]
    lowest = by_key.loc[selection["lowest_rmse"]]
    docs = ROOT / "docs"
    parts = []

    def add(text):
        parts.append(text.strip() + "\n")

    def figure(number):
        row = figures[number]
        label = "图" + (str(int(number)) if number.isdigit() else number)
        add(f"![{label} {row['title']}]({row['png']})\n\n**{label} {row['caption']}**")
        add(row["description"])

    add("# 第二题：基于特征工程与正则化线性回归的房源租金预测")
    add(f"本实验以原始特征线性回归为基线，在训练集内部比较编码、组合、二次特征、样条、PCA 和 PLS，最终采用二次特征与 Lasso。测试集 RMSE 为 **{final['test']['rmse']:.2f} 元/月**，MAE 为 **{final['test']['mae']:.2f} 元/月**，$R^2$ 为 **{final['test']['r2']:.4f}**。所有测试预测在模型锁定后生成。")
    add("## 2.1 问题重述")
    add("第二组模拟房源数据包含房屋基本信息、地理位置及配套条件。需要利用 7,500 条训练记录建立回归模型，对 1,500 条测试记录预测月租金，并评价预测误差。报告需要明确最终数学表达式、实验过程、必要图形及选择依据，完整程序与报告设置保持一致。PCA、t-SNE、UMAP 是辅助可视化的可选方式，不是必须使用的预测输入。")
    add("## 2.2 数据说明与探索性分析")
    add("### 2.2.1 字段、单位与数据质量")
    units = ["m²", "年", "km，原表米数除以 1000", "km", "间", "层", "个", "1—5 分", "0／1", "小时"]
    rows = []
    for j, (name, label, unit) in enumerate(zip(NAMES, LABELS, units)):
        rows.append([f"$x_{{{j+1}}}$", name, label, unit, f"{x[:,j].min():.3f}—{x[:,j].max():.3f}"])
    add(table(["符号", "程序变量", "含义", "单位／取值", "训练范围"], rows))
    add(f"目标 $y$ 为月租金，单位元/月；listing_id 只负责记录对齐。训练集没有缺失值、重复编号或完全相同的特征行。原始租金偏度为 {audit['target_skew']:.4f}，对数租金偏度为 {audit['log_target_skew']:.4f}，故主实验保留原尺度。线性回归拟合不要求目标本身服从正态分布。")
    add(f"数据中有 {audit['no_elevator_high_floor']} 条无电梯且楼层不低于十层的记录。题目说明这些是模拟数据，因此没有仅凭生活经验删除它们。所有实验保留完整训练集；测试标签不参与特征构造、变换拟合或模型选择。")
    add("### 2.2.2 样本关系与建模线索")
    figure("01")
    figure("02")
    add("面积与卧室数相关系数约为 0.868，市中心距离与配套数约为 −0.809，地铁距离与市中心距离约为 0.707。相关输入可能使单个系数的分配不稳定，但不说明应该直接删除其中一个变量。楼层的单变量相关性较弱，也不能排除它与电梯状态共同发挥作用。")
    figure("03")
    add("据此提出三类问题：原始线性关系是否足够；少量有含义的变换及交互能否补足关系；相关特征是否需要通过惩罚或降维处理。每个问题分别设置对照实验，不将散点或箱线图中的直观差异当作最终结论。")

    add("## 2.3 特征工程与候选模型")
    add("### 2.3.1 从数据特点到特征方案")
    add(table(["特征方案", "具体设置", "要验证的假设"], [
        ["原始特征", "10 个输入，生成后标准化", "直接线性表达是否足够"],
        ["类别编码", "卧室、装修分别用数值或独热编码；类别 1 为参照", "相邻等级是否具有相同增量"],
        ["含义组合", "原始特征与四组派生项；单组、完整、逐组移除", "少量先验组合能否提高精度"],
        ["二次特征", "10 个一次项与平方／交互项，删除电梯平方，共 64 项", "弯曲与交互关系是否重要"],
        ["加性样条", "面积、房龄、两种距离、楼层、配套数、日照使用三次样条", "平滑非线性是否合适"],
        ["PCA 回归", "标准化后保留 1—10 个成分，OLS 或 Ridge", "压缩输入是否损失预测信息"],
        ["PLS 回归", "标准化后比较 1—10 个成分", "利用目标寻找预测方向是否更有效"]]))
    add("独热编码的四种组合包含原始数值基线和另外三种编码方式。样条节点数比较 3、4、5，位置按当前训练折的分位数确定；端点外采用线性延伸。样条和二次模型对输入可以非线性，但对待估系数仍线性。")
    add(table(["特征组", "新增项", "逻辑依据"], [
        ["空间", "$x_1/x_5$", "面积相同但卧室数量不同时，空间分配可能不同"],
        ["区位", "$\log(1+x_3)$、$\log(1+x_4)$", "距离效应可能随距离增加而减弱"],
        ["通行", "$x_6(1-x_9)$", "无电梯时的高楼层可能具有不同影响"],
        ["品质", "$x_1x_8$、$x_2x_8$", "装修影响可能随面积、房龄变化"]]))
    add("这些仅是待检验假设。派生项不使用租金，不构造目标泄漏特征。高相关变量不直接删除，也不把所有新特征预设为有效。特征工程后，各列在训练折内标准化；验证折只执行已有变换。")
    add("### 2.3.2 模型、标准化与惩罚")
    add(r"""设特征工程得到 $\phi_j(\boldsymbol{x})$，标准化后记为 $z_j$：

$$
z_j=\frac{\phi_j(\boldsymbol{x})-\mu_j}{s_j},\qquad
\hat y=b+\sum_{j=1}^{p}\theta_jz_j.
$$

普通回归及三类正则化可统一写为：

$$
J(b,\boldsymbol{\theta})=
\frac{1}{2n}\sum_{i=1}^{n}(y_i-\hat y_i)^2
+\lambda_1\sum_{j=1}^{p}\lvert\theta_j\rvert
+\frac{\lambda_2}{2}\sum_{j=1}^{p}\theta_j^2.
$$

OLS 的两个惩罚系数为零；Ridge 缩小系数；Lasso 还可能使部分系数变为零；Elastic Net 同时使用两类惩罚。截距不惩罚。标准化让不同单位的特征处于可比较尺度；并不改变数据中的信息量。

sklearn 的 Ridge 对应 $\lambda_2=\alpha/n$，Lasso 对应 $\lambda_1=\alpha$，Elastic Net 对应 $\lambda_1=\alpha\rho$、$\lambda_2=\alpha(1-\rho)$。因此不同方法相同数值的 alpha 不代表相同惩罚。

最终系数还原为：

$$
\beta_j=\frac{\theta_j}{s_j},\qquad
\beta_0=b-\sum_{j=1}^{p}\frac{\theta_j\mu_j}{s_j},\qquad
\hat y=\beta_0+\sum_{j=1}^{p}\beta_j\phi_j(\boldsymbol{x}).
$$""")
    add("### 2.3.3 调研经验与本题取舍")
    add("Kaggle 的数据探索与正则化线性模型案例启发了分布检查、交叉验证、组合特征和系数分析。本题仅有十个数值输入且没有缺失值，因此不照搬 Ames 数据的地下室、社区和车库特征，也不增加无用途的填补流程。原目标较对称且评价以元/月的 RMSE 为主，没有预先把租金取对数。部分旧案例将训练与测试合并处理，本实验改为严格在训练折内拟合流水线。")

    add("## 2.4 降维分析与辅助可视化")
    add("### 2.4.1 PCA 的原理与线性投影")
    add("PCA 在标准化输入上寻找保留输入方差较多的正交方向，不使用租金。PCA 回归随后用这些成分预测租金；高方差方向不一定最有预测价值。PLS 在训练阶段同时利用输入与租金信息寻找方向，因此是有监督降维，必须在每个训练折内部拟合。")
    figure("04")
    figure("05")
    add("### 2.4.2 t-SNE、UMAP 及解释边界")
    add("三种投影使用相同的固定 3,000 条训练子样本、标准化输入与颜色范围。租金仅用于最终着色，没有进入 PCA、t-SNE、UMAP 的拟合。正文采用预先指定的设置：t-SNE 困惑度 30、PCA 初始化；UMAP 邻居数 30、最小距离 0.1；种子均为 42，不按图形好看程度挑选运行结果。")
    figure("06")
    add("t-SNE 与 UMAP 突出局部邻域关系，但图中簇间距离、面积和空隙不应直接解释为原始空间的距离或密度。标准 sklearn t-SNE 没有常规的新样本 transform；UMAP 虽支持新样本转换，本实验仍仅将其用于可视化，使最终预测模型保留明确的代数表达式。")
    embed = pd.read_csv(output / "embedding_metrics.csv")
    stability = pd.DataFrame(load("embedding_stability.json"))
    stats = embed.groupby("method").agg(count=("method", "size"), trust_mean=("trustworthiness", "mean"),
                                       trust_min=("trustworthiness", "min"), trust_max=("trustworthiness", "max"),
                                       neighbor=("neighbor_overlap", "mean"))
    add(table(["方法", "运行数", "邻域可信度均值", "范围", "原始近邻重合比例"],
              [[m, int(r['count']), f"{r.trust_mean:.4f}", f"{r.trust_min:.4f}—{r.trust_max:.4f}",
                f"{r.neighbor:.4f}"] for m, r in stats.iterrows()]))
    add("上述邻域指标均使用 15 个近邻。原计划的 27 组参数／种子实验完成后，发现 PCA 初始化下 t-SNE 更换种子得到相同投影；另外增加三次随机初始化检查，共 30 次运行。PCA 初始化的重复结果只证明该设置下可重复，不能证明对任意初始化稳定。随机初始化和 UMAP 的近邻稳定性见补充图 S1 及完整记录。")

    add("## 2.5 实验设计与模型选择")
    add("### 2.5.1 评价指标与数据隔离")
    add(r"""以 RMSE 为主要选择指标，同时报告 MAE 与 $R^2$。前两者单位均为元/月。

$$
\begin{aligned}
\operatorname{RMSE}&=\sqrt{\frac{1}{n}\sum_{i=1}^{n}(y_i-\hat y_i)^2},\\
\operatorname{MAE}&=\frac{1}{n}\sum_{i=1}^{n}\lvert y_i-\hat y_i\rvert,\\
R^2&=1-\frac{\sum_i(y_i-\hat y_i)^2}{\sum_i(y_i-\bar y)^2}.
\end{aligned}
$$""")
    add("外层采用五折随机划分，种子 42，每次 6,000 条用于开发、1,500 条用于外层验证；内层三折种子 2026，每次 4,000 条训练、2,000 条验证。所有候选共享划分。每种特征家族与求解方法是一个明确候选，其编码、派生组、节点数、成分数和惩罚强度在内层选择。每条训练房源恰获得一次对应外层模型的折外预测。")
    add("Ridge 初始 alpha 网格为 $10^{-4}$ 至 $10^4$，每数量级一点；Lasso 与 Elastic Net 为 $10^{-3}$ 至 $10^3$，每半数量级一点；Elastic Net 的 L1 比例为 0.1、0.5、0.9。某种惩罚的最优值位于边界时，仅向对应方向扩展两个数量级一次。搜索只使用内层信息，所有扩展均保存。Lasso 与 Elastic Net 设置 50,000 次上限、容差 $10^{-6}$，若出现收敛警告重试至 200,000 次，仍失败则排除。")
    logs = [load(str(p.relative_to(output))) for p in output.glob("fold_*/*_search.json")]
    trials = sum(len(d["records"]) for d in logs)
    failed = sum(not r["valid"] for d in logs for r in d["records"])
    add(f"外层共完成 35 个特征家族搜索任务，含扩展后累计 {trials:,} 个候选配置记录，每个配置在三折内层验证；失败候选数为 {failed}。边界扩展、逐折参数和全部有效／失败记录均随程序交付。")
    add("外层结果用于候选比较，仍存在从多个候选中选择带来的选择效应，因此不把最小外层误差宣传为完全无偏的最终泛化估计。独立测试集仅在最终选择、全训练集调参和模型锁定之后评价。折间标准差是描述波动，不是置信区间。")
    add("### 2.5.2 降维是否改善预测")
    add("图4右侧给出了成分数与外层验证误差的对应关系。PCA 仅保留两个成分时平均 RMSE 约为 410.25 元/月，九个成分仍约为 262.15 元/月；全部十个成分时接近原始 OLS 的 185.49 元/月。这表明输入变化较小的方向仍可能承载预测信息。PLS 五个成分约为 188.04 元/月，较快接近完整原始模型，但未突破其线性表达能力。故本题不采用降维作为主要预测改进。")
    add("PCA 与 PLS 通过验证实验参与了候选方案比较，但未进入最终预测流水线；t-SNE 与 UMAP 仅用于描述训练样本结构。最终多项式项的保留由特征构造、训练集内调参及 Lasso 系数决定，不根据二维图中的分区或租金颜色删留特征。")
    add("### 2.5.3 特征工程与消融结果")
    figure("07")
    family_rows = []
    for family in FAMILY_LABEL:
        subset = eligible[eligible.family == family]
        best = subset.loc[subset.rmse.idxmin()]
        method = best.candidate.split(":")[1]
        family_rows.append([FAMILY_LABEL[family], METHOD_LABEL[method], f"{best.rmse:.3f} ± {best.rmse_std:.3f}",
                            f"{best.mae:.3f}", f"{best.r2:.5f}"])
    add(table(["特征家族", "最低误差方法", "外层 RMSE：均值 ± 标准差", "MAE", "$R^2$"], family_rows))
    mean = by_key.loc["mean:mean"]
    add(f"仅预测训练均值的基线 RMSE 为 {mean.rmse:.2f} 元/月，说明输入特征提供了大量预测信息。类别编码相较原始模型有有限改善；含义组合进一步降至约 155.59 元/月。二次项与样条降至约 129 元/月，说明输入与租金之间的弯曲或交互关系是本题主要改进来源。")
    full_key = "ablation:" + "+".join(BLOCKS)
    full = by_key.loc[full_key, "rmse"]
    ablation_rows = []
    for block in BLOCKS:
        single = by_key.loc["ablation:"+block, "rmse"]
        removed = by_key.loc["ablation:"+"+".join(b for b in BLOCKS if b != block), "rmse"]
        ablation_rows.append([BLOCK_LABEL[block], f"{single:.3f}", f"{removed:.3f}", f"{removed-full:+.3f}"])
    add(table(["特征组", "仅加入该组的 RMSE", "完整组合移除该组的 RMSE", "移除后的误差增量"], ablation_rows))
    add(f"完整组合 Ridge 的 RMSE 为 {full:.3f} 元/月。区位组带来的增益最大，通行组次之；空间组与品质组的额外改善很小。结果支持距离变换与楼层—电梯交互，但不能据此断言每个派生项都必要；最终模型仍由统一验证规则确定。")
    add("### 2.5.4 正则化与最终取舍")
    figure("08")
    rows = []
    for family in ["raw", "domain", "quadratic", "spline"]:
        row = [FAMILY_LABEL[family]]
        for method in ["ols", "ridge", "lasso", "elastic"]:
            result = by_key.loc[f"{family}:{method}"]
            row.append(f"{result.rmse:.3f}")
        rows.append(row)
    add(table(["特征方案", "OLS RMSE", "Ridge RMSE", "Lasso RMSE", "Elastic Net RMSE"], rows))
    add("原始特征和含义组合中的不同惩罚结果非常接近，说明本数据规模下，正则化没有自动带来明显的精度收益。在二次特征中，Lasso 将平均非零项从 OLS 的 64 项减至 36.6 项，RMSE 从 129.865 降至 129.591 元/月。该变化主要支持简化表达，不能夸大为显著精度优势。非零项数在折间变化，最终全训练集拟合的项数单独报告。")
    add(f"最低外层平均误差为样条＋Lasso 的 {lowest.rmse:.6f} 元/月，其标准差为 {lowest.rmse_std:.6f}。按事先确定的一个标准误规则，候选阈值为 {selection['threshold']:.6f} 元/月。二次特征＋Lasso 的 {chosen.rmse:.6f} 在阈值内，因此按“原始线性表达、少量组合、二次、样条”的优先顺序选用二次方案；同类再优先平均非零项少者。它比最低误差方案高 {chosen.rmse-lowest.rmse:.3f} 元/月，换取无需样条节点的显式多项式。该选择是预设的精度与简洁性取舍，不是说它取得了最低验证误差。")

    add("## 2.6 最终模型及其解释")
    add("### 2.6.1 完整数学表达式")
    count = sum(v != 0 for v in formula["coefficients"])
    alpha = locked["params"]["model__alpha"]
    add(f"在全部 7,500 条训练记录内部重新进行五折调参后，Lasso 的 alpha 为 {alpha:.12g}，最终从 64 个候选项中保留 **{count} 个非零项**。")
    figure("09")
    add("下式直接接受 2.2.1 节字段表中的原始单位变量，已还原标准化，无需再手工标准化输入；地铁距离 $x_3$ 必须使用千米。")
    if formula["feature_spec"]["kind"] != "quadratic":
        raise ValueError("报告的数值展开应与实际入选特征方案相符。")
    add(polynomial_expression(formula))
    add("上述系数显示为十位有效数字，程序另保存完整浮点系数。电梯一次项系数为零，但电梯仍出现在楼层等交互项中，因此不能解释为电梯特征没有作用。其余未出现在公式中的候选项系数为零。")
    coefficient_rows = [["截距", f"{formula['intercept']:.12g}"]]
    coefficient_rows += [["$"+term_math(name)+"$", f"{v:.12g}"] for name, v in zip(formula["names"], formula["coefficients"]) if v != 0]
    add(table(["保留项", "原始单位系数"], coefficient_rows))
    add("### 2.6.2 单条房源复算与影响分析")
    values = r",\ ".join(f"{v:.12g}" for v in test_x[0])
    add(f"以测试房源 **{test_ids[0]}** 为例，按字段顺序的输入为：\n\n$$\n\\boldsymbol{{x}}=({values}).\n$$")
    add(f"将上述输入代入完整公式，得到预测租金 {pred.predicted_rent.iloc[0]:.6f} 元/月；实际租金为 {test_y[0]:.6f} 元/月，残差（实际减预测）为 {pred.residual.iloc[0]:.6f} 元/月。所有 1,500 条预测均保存在单独 CSV 中，不只展示示例。")
    figure("10")
    add("面积的局部平均影响整体上升，增长逐渐放缓。地铁距离曲线在约 3—4 km 后出现回升，表明二次近似在尾部具有局限，也受到相邻真实房源中其他变量分布的影响；不能把这一模型形状解释为远离地铁导致租金上升。ALE 通过训练数据的 20 个分位区间比较局部预测差异，减少全范围替换造成的不合理组合，但仍不是因果分析。")

    add("## 2.7 测试集预测与误差分析")
    add(table(["数据范围", "RMSE（元/月）", "MAE（元/月）", "$R^2$"],
              [[label, f"{m['rmse']:.6f}", f"{m['mae']:.6f}", f"{m['r2']:.6f}"]
               for label, m in [("全训练集重拟合", final["train"]), ("独立测试集", final["test"])]]))
    add("训练重拟合误差不是验证误差。两者接近只说明本次样本划分中未出现明显训练—测试落差，不保证其他城市、年份或分布下仍有效。本题为模拟数据，模型结论限定在提供的数据范围。测试集结果没有用于后续调参。")
    figure("11")
    figure("12")
    absolute = np.abs(pred.residual)
    add(table(["绝对误差中位数", "90% 分位数", "95% 分位数", "最大值", "残差均值"],
              [[f"{absolute.median():.3f}", f"{absolute.quantile(.9):.3f}", f"{absolute.quantile(.95):.3f}",
                f"{absolute.max():.3f}", f"{pred.residual.mean():.3f}"]]))
    # 分组边界由训练集分位数确定，测试分组仅用于最终误差描述。
    cuts = np.quantile(y, [1/3, 2/3])
    group = np.digitize(test_y, cuts)
    group_rows = []
    for i, label in enumerate(["低租金组", "中租金组", "高租金组"]):
        residual = pred.residual.to_numpy()[group == i]
        group_rows.append([label, len(residual), f"{np.sqrt(np.mean(residual**2)):.3f}",
                           f"{np.mean(np.abs(residual)):.3f}", f"{residual.mean():.3f}"])
    add(f"按训练租金三分位数 {cuts[0]:.3f} 和 {cuts[1]:.3f} 元/月划分测试样本，分组结果如下。这是模型锁定后的描述性诊断，不反向调整模型。")
    add(table(["测试分组", "样本数", "RMSE", "MAE", "平均残差"], group_rows))
    add(table(["房源编号", "实际租金", "预测租金", "残差"],
              [[r.listing_id, f"{r.actual_rent:.3f}", f"{r.predicted_rent:.3f}", f"{r.residual:.3f}"] for r in pred.head(8).itertuples()]))
    add("完整预测文件：[test_predictions.csv](../results/complete/test_predictions.csv)。数值参数：[final_formula.json](../results/complete/final_formula.json)。模型选择记录：[selection.json](../results/complete/selection.json)。")

    add("## 2.8 程序组织与实验复现")
    add("### 2.8.1 环境、运行方式与输出")
    env = load("environment.json")
    add(table(["依赖", "实际版本"], list(env["packages"].items())))
    add("本次使用 medsafety 的 Python 3.10。该环境原先缺少 UMAP，兼容依赖安装在项目 .deps 目录，由入口加载；没有更换解释器。可移植交付包提供版本固定的 requirements-q2.txt，在 medsafety 中安装后同样可运行。")
    add("```powershell\nconda activate medsafety\npython -m pip install -r requirements-q2.txt\npython -m question2.run --stage all\n```")
    add("命令在项目根目录执行。compare 仅执行训练集验证，finalize 锁定模型并完成测试评价，embedding 计算投影，plot 只读取结果重绘，report 生成文档，verify 执行验证。若修改实验配置，请同时指定新的输出目录，避免与已完成实验混合；本次完整结果位于 results/complete。已有最终测试结果时 finalize 使用已有结果，不反复触发模型选择。")
    add("数据与特征、实验搜索、投影、绘图、报告和验证分别组织成小模块。使用 sklearn Pipeline 与 GridSearchCV，保持拟合范围清晰，无额外框架依赖。外层五折和内层索引、完整搜索记录、边界扩展、逐折系数、折外预测、最终模型、数据哈希及参数均保存。最主要的检查包括公式独立复算、全成分 PCR 与 OLS 一致、输入标识对齐、训练变换不依赖验证数据，以及图文与源码一致。")
    add("### 2.8.2 完整代码与配置")
    add("下列清单按实际文件自动嵌入，可直接对应本次运行文件。绘图代码较长是因为每张图独立表达具体问题；公共配色、保存和坐标样式集中管理。")
    files = [ROOT / "configs/q2.yaml"] + sorted((ROOT / "question2").glob("*.py"))
    source_manifest = []
    for path in files:
        relative = path.relative_to(ROOT).as_posix()
        source = path.read_text(encoding="utf-8")
        language = "yaml" if path.suffix == ".yaml" else "python"
        add(f"#### {relative}\n\n```{language}\n{source.rstrip()}\n```")
        source_manifest.append(dict(path=relative, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
    save_json(output / "report_sources.json", source_manifest)

    add("## 2.9 本题结论")
    add(f"本题在原始线性回归基础上，通过受控实验验证了特征表达的重要性。PCA 压缩没有改善预测，PLS 用更少成分接近完整线性模型；距离变换与楼层—电梯交互有效，空间比例与品质组合的额外收益较小。二次项和样条均明显改善预测，单纯加强正则化的收益相对有限。")
    add(f"样条＋Lasso 的外层 RMSE 最低，但按预设简洁性规则选取二次特征＋Lasso。其最终保留 {count} 项，测试 RMSE 为 {final['test']['rmse']:.2f} 元/月，MAE 为 {final['test']['mae']:.2f} 元/月，$R^2$ 为 {final['test']['r2']:.4f}。结论以提供的模拟样本、候选范围和指标为限，不能将投影分组或模型系数解释为因果关系，也不建议在输入范围之外外推。")
    add("## 补充结果")
    for number in ["S1", "S2", "S3"]:
        figure(number)
    add("### 全部主要候选结果")
    add(table(["候选", "RMSE", "折间标准差", "MAE", "$R^2$", "平均非零项"],
              [[r.candidate, f"{r.rmse:.6f}", f"{r.rmse_std:.6f}", f"{r.mae:.6f}", f"{r.r2:.6f}", f"{r.nonzero:.1f}"]
               for r in eligible.sort_values("rmse").itertuples()]))
    add("### 文档与预览说明")
    add("本文件使用 UTF-8 和可编辑 LaTeX，行内公式使用美元符号，独立公式使用单独成行的双美元符号。插图采用相对路径，与 figures 目录一同移动即可。已检查 PNG 图像、公式定界符、引用文件和源码一致性；未实际打开 Markpad 或 Obsidian，因此不声称已完成这两个阅读器的界面渲染验证。")
    add("## 参考资料")
    sources = [
        ("Kaggle：Comprehensive data exploration with Python", "https://www.kaggle.com/code/pmarcelino/comprehensive-data-exploration-with-python"),
        ("Kaggle：Regularized Linear Models", "https://www.kaggle.com/code/apapiu/regularized-linear-models"),
        ("Kaggle：Stacked Regressions（仅借鉴工程与验证思路）", "https://www.kaggle.com/code/serigne/stacked-regressions-top-4-on-leaderboard"),
        ("scikit-learn：PCR versus PLS", "https://scikit-learn.org/stable/auto_examples/cross_decomposition/plot_pcr_vs_pls.html"),
        ("scikit-learn：Polynomial and spline interpolation", "https://scikit-learn.org/stable/auto_examples/linear_model/plot_polynomial_interpolation.html"),
        ("scikit-learn：Common pitfalls and data leakage", "https://scikit-learn.org/stable/common_pitfalls.html"),
        ("scikit-learn：TSNE", "https://scikit-learn.org/stable/modules/generated/sklearn.manifold.TSNE.html"),
        ("Distill：How to Use t-SNE Effectively", "https://distill.pub/2016/misread-tsne/"),
        ("UMAP：Transforming new data", "https://umap-learn.readthedocs.io/en/latest/transform.html"),
        ("Interpretable Machine Learning：ALE", "https://christophm.github.io/interpretable-ml-book/ale.html")]
    add("\n".join(f"- [{label}]({url})" for label, url in sources))
    (docs / "第二题_实验报告.md").write_text("\n".join(parts), encoding="utf-8")
    print("REPORT", docs / "第二题_实验报告.md", flush=True)
