"""运行入口：python -m question2.run --stage compare。"""

import argparse
import yaml
from . import ROOT


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="configs/q2.yaml")
    parser.add_argument("--stage", choices=["all", "compare", "finalize", "embedding", "plot", "report", "verify"], default="all")
    args = parser.parse_args()
    config = yaml.safe_load((ROOT / args.config).read_text(encoding="utf-8"))
    output = ROOT / config["output"]
    output.mkdir(parents=True, exist_ok=True)
    snapshot = output / "config.yaml"
    current = yaml.safe_dump(config, allow_unicode=True, sort_keys=False)
    if snapshot.exists() and snapshot.read_text(encoding="utf-8") != current:
        raise ValueError("输出目录已有不同配置；请在配置中指定新的 output 目录。")
    snapshot.write_text(current, encoding="utf-8")
    if args.stage in {"all", "compare", "finalize"}:
        from .experiment import run_training
        run_training(config, output, args.stage)
    if args.stage in {"all", "embedding"}:
        from .embedding import run_embeddings
        run_embeddings(config, output)
    if args.stage in {"all", "plot"}:
        from .plot import draw_all
        draw_all(config, output)
    if args.stage in {"all", "report"}:
        from .report import build_report
        build_report(config, output)
    if args.stage in {"all", "verify"}:
        from .verify import verify
        verify(config, output)


if __name__ == "__main__":
    main()
