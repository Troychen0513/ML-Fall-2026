"""验证数据隔离、数值表达、样本对齐和交付文件的一致性。"""

import hashlib
import json
import re
import joblib
import numpy as np
import pandas as pd
from PIL import Image
from sklearn.base import clone
from . import ROOT
from .features import NAMES, read_data, export_formula, save_json
from .experiment import pipeline_for, metrics
from .plot import ale_curve


def independent_polynomial(x, formula, rounded=False):
    """按导出的项名逐项计算，不调用特征变换器或模型预测。"""
    intercept = float(f"{formula['intercept']:.10g}") if rounded else formula["intercept"]
    result = np.full(len(x), intercept)
    for name, coefficient in zip(formula["names"], formula["coefficients"]):
        coefficient = float(f"{coefficient:.10g}") if rounded else coefficient
        column = np.ones(len(x))
        for token in name.split():
            base, *power = token.split("^")
            exponent = int(power[0]) if power else 1
            column *= x[:, NAMES.index(base)] ** exponent
        result += coefficient * column
    return result


def verify(config, output):
    def load(name):
        return json.loads((output / name).read_text(encoding="utf-8"))
    passed = []
    ids, x, y = read_data(ROOT / config["data"]["train"])
    test_ids, xt, yt = read_data(ROOT / config["data"]["test"])
    assert len(y) == 7500 and len(yt) == 1500 and not set(ids) & set(test_ids)
    assert x.shape[1] == 10 and "listing_id" not in NAMES and "monthly_rent" not in NAMES
    for name, path in config["data"].items():
        actual = hashlib.sha256((ROOT / path).read_bytes()).hexdigest()
        assert actual == load("environment.json")["data_sha256"][name]
    passed.append("数据未改变；编号独立；仅使用十个合法输入")

    coverage = np.zeros(len(y), int)
    for i, fold in enumerate(load("folds.json")):
        train, valid = np.array(fold["train"]), np.array(fold["valid"])
        assert len(train) == 6000 and len(valid) == 1500 and not set(train) & set(valid)
        coverage[valid] += 1
        inner_coverage = np.zeros(len(train), int)
        for inner in load(f"fold_{i+1}/inner_folds.json"):
            a, b = np.array(inner["train"]), np.array(inner["valid"])
            assert len(a) == 4000 and len(b) == 2000 and not set(a) & set(b)
            assert not set(train[a]) & set(valid) and not set(train[b]) & set(valid)
            inner_coverage[b] += 1
        assert np.all(inner_coverage == 1)
    assert np.all(coverage == 1)
    assert load("selection.json")["test_used"] is False
    passed.append("五折外层与三折内层覆盖完整、无交叉；选择记录未使用测试集")

    model = joblib.load(output / "final_model.joblib")
    formula = load("final_formula.json")
    pred = model.predict(xt).reshape(-1)
    direct = independent_polynomial(xt, formula)
    equation_error = float(np.max(np.abs(pred-direct)))
    rounded_error = float(np.max(np.abs(pred-independent_polynomial(xt, formula, rounded=True))))
    assert equation_error < 1e-7 and rounded_error < 1e-4
    train_direct = independent_polynomial(x, formula)
    assert np.max(np.abs(train_direct-model.predict(x).reshape(-1))) < 1e-7
    stored = pd.read_csv(output / "test_predictions.csv")
    assert np.array_equal(stored.listing_id, test_ids)
    assert np.allclose(stored.actual_rent, yt, atol=1e-9, rtol=0)
    assert np.allclose(stored.predicted_rent, pred, atol=1e-7, rtol=0)
    assert np.allclose(stored.residual, yt-pred, atol=1e-7, rtol=0)
    permutation = np.random.default_rng(42).permutation(len(xt))
    assert np.allclose(model.predict(xt[permutation]).reshape(-1), pred[permutation], atol=1e-8)
    assert hashlib.sha256((output / "final_model.joblib").read_bytes()).hexdigest() == load("model_lock.json")["model_sha256"]
    for key, value in metrics(yt, pred).items():
        assert np.isclose(value, load("final_metrics.json")["test"][key], atol=1e-9)
    passed.append("独立多项式与报告舍入公式可复算；1500 条预测、残差、指标与模型锁定文件一致")

    # 在较小训练子集上检查代数恒等性，不重复执行完整搜索。
    raw = pipeline_for("raw").fit(x[:600], y[:600])
    pcr = pipeline_for("pcr").set_params(pca__n_components=10).fit(x[:600], y[:600])
    assert np.max(np.abs(raw.predict(x[600:800])-pcr.predict(x[600:800]))) < 1e-7
    for family in ["raw", "encoded", "domain", "quadratic", "spline", "pcr", "pls"]:
        candidate = pipeline_for(family)
        if family == "encoded":
            candidate.set_params(features__categories=(4, 7))
        candidate.fit(x[:600], y[:600])
        exported = export_formula(candidate)
        design = candidate.named_steps["features"].transform(x[600:800])
        manual = exported["intercept"] + design @ exported["coefficients"]
        assert np.max(np.abs(manual-candidate.predict(x[600:800]).reshape(-1))) < 1e-7
        expected_mean = candidate.named_steps["features"].transform(x[:600]).mean(axis=0)
        assert np.allclose(candidate.named_steps["scale"].mean_, expected_mean)
        before = candidate.named_steps["scale"].mean_.copy()
        changed = x[600:800].copy()
        changed[:, 0] += 100
        candidate.predict(changed)
        assert np.array_equal(before, candidate.named_steps["scale"].mean_)
    raw_formula = export_formula(raw)
    for j in [0, 2]:
        edges, effect = ale_curve(raw, x[:600], j)
        expected = raw_formula["coefficients"][j] * (edges-x[:600, j].mean())
        assert np.max(np.abs(effect-expected)) < 1e-7
    passed.append("全成分 PCR 与 OLS 一致；七类参数还原正确；预测不重拟合尺度；线性 ALE 与解析式一致")

    oof = np.load(output / "oof_predictions.npz")
    rows = pd.read_csv(output / "fold_metrics.csv")
    for row in rows.itertuples():
        valid = load("folds.json")[row.fold-1]["valid"]
        actual = metrics(y[valid], oof[row.candidate][valid])
        assert np.isclose(actual["rmse"], row.rmse, atol=1e-8)
    assert np.array_equal(oof["listing_id"], ids)
    passed.append("全部逐折误差可从保存的折外预测重新计算")

    pca_data = np.load(output / "pca.npz")
    assert len(pca_data["sample"]) == 3000 and len(np.unique(pca_data["sample"])) == 3000
    assert np.array_equal(pca_data["y"], y[pca_data["sample"]])
    embedding = pd.read_csv(output / "embedding_metrics.csv")
    assert len(embedding) == 30
    for file in embedding.file:
        z = np.load(output / "embeddings" / file)["coords"]
        assert z.shape == (3000, 2) and np.isfinite(z).all()
    passed.append("三种投影共用训练样本；30 组投影记录完整")

    report_path = ROOT / "docs/第二题_实验报告.md"
    report = report_path.read_text(encoding="utf-8")
    for item in load("report_sources.json"):
        path = ROOT / item["path"]
        assert hashlib.sha256(path.read_bytes()).hexdigest() == item["sha256"]
        source = path.read_text(encoding="utf-8").rstrip()
        assert source in report
    plain = re.sub(r"(?ms)^```[^\n]*\n.*?^```[ \t]*$", "", report)
    assert r"\(" not in plain and r"\[" not in plain
    math_lines = [line for line in plain.splitlines() if "$$" in line]
    assert all(line.strip() == "$$" for line in math_lines) and len(math_lines) % 2 == 0
    for document in (ROOT / "docs").glob("*.md"):
        contents = document.read_text(encoding="utf-8")
        for path in re.findall(r"!\[[^\]]*\]\(([^)]+)\)", contents):
            assert (document.parent / path).exists()
    figures = load("figures.json")
    assert {f["number"] for f in figures} == {f"{i:02d}" for i in range(1, 13)} | {"S1", "S2", "S3"}
    for fig in figures:
        assert fig["panels"] <= 2
        for field in ["png", "svg"]:
            assert (report_path.parent / fig[field]).is_file()
        with Image.open(report_path.parent / fig["png"]) as im:
            assert im.width >= 1400 and im.height >= 700
    passed.append("15 张 PNG/SVG 完整；图片路径、公式定界符、正文源码与实际文件相符")
    result = dict(passed=passed, equation_max_error=equation_error,
                  report_rounded_equation_max_error=rounded_error,
                  reader_preview="未实际打开 Markpad/Obsidian；仅核验语法、路径及 PNG 图像")
    save_json(output / "verification.json", result)
    print(json.dumps(result, ensure_ascii=False, indent=2), flush=True)
